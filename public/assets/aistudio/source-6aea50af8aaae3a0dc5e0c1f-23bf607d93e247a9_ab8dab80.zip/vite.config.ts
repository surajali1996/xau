import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
import {VitePWA} from 'vite-plugin-pwa';

export default defineConfig(() => {
  return {
    plugins: [
      react(),
      tailwindcss(),
      VitePWA({
        registerType: 'autoUpdate',
        injectRegister: 'auto',
        filename: 'sw.js',
        includeAssets: ['icon.svg', 'apple-touch-icon.png'],
        manifest: {
          id: '/',
          name: 'Binance Futures TradingView Pro',
          short_name: 'Futures Pro',
          description:
            'Professional Binance Futures trading terminal with real-time feeds, drawings, bar replay and price alerts.',
          start_url: '/',
          scope: '/',
          display: 'standalone',
          display_override: ['window-controls-overlay', 'standalone'],
          orientation: 'any',
          background_color: '#131722',
          theme_color: '#131722',
          categories: ['finance', 'business'],
          icons: [
            {src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any'},
            {src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any'},
            {src: '/maskable-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable'},
            {src: '/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any'},
          ],
        },
        workbox: {
          // Reuse the existing push-notification handlers inside the single app service worker
          importScripts: ['/firebase-messaging-sw.js'],
          globPatterns: ['**/*.{js,css,html,svg,png,ico,woff2}'],
          globIgnores: ['firebase-messaging-sw.js'],
          maximumFileSizeToCacheInBytes: 6 * 1024 * 1024,
          navigateFallback: '/index.html',
          navigateFallbackDenylist: [/^\/\.netlify\//, /^\/api\//],
          cleanupOutdatedCaches: true,
          clientsClaim: true,
          skipWaiting: true,
        },
      }),
    ],
    resolve: {
      alias: {
        '@': path.resolve(import.meta.dirname || '.', '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
