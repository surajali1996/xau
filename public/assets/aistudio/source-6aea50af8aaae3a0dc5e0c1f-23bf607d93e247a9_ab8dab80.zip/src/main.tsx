import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import {initPWAInstallCapture} from './hooks/usePWAInstall';
import './index.css';

initPWAInstallCapture();

createRoot(document.getElementById('root')!).render(<App />);
