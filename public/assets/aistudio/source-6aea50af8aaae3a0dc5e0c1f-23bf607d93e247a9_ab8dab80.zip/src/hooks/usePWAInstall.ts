import { useEffect, useState } from 'react';

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

// Shared store so the install event is captured as early as possible (before React mounts)
// and every component using the hook sees the same state.
let deferredPrompt: BeforeInstallPromptEvent | null = null;
let installed = false;
const listeners = new Set<() => void>();
const notify = () => listeners.forEach((l) => l());

export function isStandaloneMode() {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    window.matchMedia('(display-mode: window-controls-overlay)').matches ||
    (window.navigator as unknown as { standalone?: boolean }).standalone === true
  );
}

export function initPWAInstallCapture() {
  if (typeof window === 'undefined') return;
  installed = isStandaloneMode();
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e as BeforeInstallPromptEvent;
    notify();
  });
  window.addEventListener('appinstalled', () => {
    installed = true;
    deferredPrompt = null;
    notify();
  });
}

function detectIOS() {
  if (typeof window === 'undefined') return false;
  const ua = window.navigator.userAgent.toLowerCase();
  // iPadOS 13+ reports itself as Mac; detect via touch support
  return /iphone|ipad|ipod/.test(ua) || (ua.includes('macintosh') && navigator.maxTouchPoints > 1);
}

export function usePWAInstall() {
  const [, force] = useState(0);
  const [isIOS] = useState(detectIOS);

  useEffect(() => {
    const l = () => force((n) => n + 1);
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);

  const install = async () => {
    if (!deferredPrompt) return false;
    const evt = deferredPrompt;
    await evt.prompt();
    const { outcome } = await evt.userChoice;
    deferredPrompt = null;
    if (outcome === 'accepted') installed = true;
    notify();
    return outcome === 'accepted';
  };

  return {
    isInstallable: !!deferredPrompt,
    isInstalled: installed || isStandaloneMode(),
    isIOS,
    install,
  };
}
