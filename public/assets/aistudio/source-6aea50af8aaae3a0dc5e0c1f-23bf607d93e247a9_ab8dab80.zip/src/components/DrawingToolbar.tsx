import React, { useEffect, useRef, useState } from 'react';
import {
  Sliders,
  Trash2,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Magnet,
  Undo2,
  Redo2,
  PanelLeftClose,
  PanelLeftOpen,
  Star,
  PencilLine,
} from 'lucide-react';
import { DrawingTool } from '../types';
import { TOOL_GROUPS, ToolGroup, getToolIcon, getToolLabel } from './drawingTools';

interface DrawingToolbarProps {
  activeTool: DrawingTool | null;
  onSelectTool: (tool: DrawingTool | null) => void;
  drawingsCount: number;
  onClearDrawings: () => void;
  onOpenSettings: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  favoriteTools?: DrawingTool[];
  onToggleFavorite?: (tool: DrawingTool) => void;
  magnetMode: boolean;
  onToggleMagnetMode: () => void;
  isAllLocked: boolean;
  onToggleLockAll: () => void;
  isAllHidden: boolean;
  onToggleHideAll: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  stayInDrawingMode?: boolean;
  onToggleStayInDrawingMode?: () => void;
  showFavoritesBar?: boolean;
  onToggleFavoritesBar?: () => void;
}

const LAST_TOOL_KEY = 'tv_group_last_tool_v1';

const loadLastTools = (): Record<string, DrawingTool> => {
  try {
    const raw = localStorage.getItem(LAST_TOOL_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return {};
};

export const DrawingToolbar: React.FC<DrawingToolbarProps> = ({
  activeTool,
  onSelectTool,
  drawingsCount,
  onClearDrawings,
  onOpenSettings,
  isCollapsed,
  onToggleCollapse,
  favoriteTools = [],
  onToggleFavorite,
  magnetMode,
  onToggleMagnetMode,
  isAllLocked,
  onToggleLockAll,
  isAllHidden,
  onToggleHideAll,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  stayInDrawingMode = true,
  onToggleStayInDrawingMode,
  showFavoritesBar = true,
  onToggleFavoritesBar,
}) => {
  const [lastTools, setLastTools] = useState<Record<string, DrawingTool>>(loadLastTools);
  const [openGroup, setOpenGroup] = useState<{ id: string; top: number; left: number } | null>(null);
  const flyoutRef = useRef<HTMLDivElement>(null);
  const longPressRef = useRef<number | null>(null);
  const longPressFiredRef = useRef(false);

  // Remember the tool chosen in each group (like TradingView)
  useEffect(() => {
    if (!activeTool) return;
    const group = TOOL_GROUPS.find((g) =>
      g.tools.some((t) => t.id === activeTool || (t.id === 'price_range' && activeTool === 'price_percentage_measure'))
    );
    if (group && lastTools[group.id] !== activeTool) {
      const next = { ...lastTools, [group.id]: activeTool };
      setLastTools(next);
      try {
        localStorage.setItem(LAST_TOOL_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
    }
  }, [activeTool, lastTools]);

  // Close flyout on outside click / Escape
  useEffect(() => {
    if (!openGroup) return;
    const onDown = (e: PointerEvent) => {
      if (flyoutRef.current && !flyoutRef.current.contains(e.target as Node)) {
        const target = e.target as HTMLElement;
        if (target.closest?.('[data-group-trigger]')) return;
        setOpenGroup(null);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpenGroup(null);
    };
    window.addEventListener('pointerdown', onDown, true);
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('pointerdown', onDown, true);
      window.removeEventListener('keydown', onKey);
    };
  }, [openGroup]);

  if (isCollapsed) {
    return (
      <div className="absolute left-1 top-12 z-30">
        <button
          onClick={onToggleCollapse}
          className="w-7 h-8 bg-[#1E222D]/95 border border-[#2B2F3A] rounded-r-md flex items-center justify-center text-[#787B86] hover:text-[#2962FF] hover:bg-[#2A2E39] shadow-lg transition-colors cursor-pointer"
          title="Expand Drawing Toolbar"
        >
          <PanelLeftOpen className="w-4 h-4" />
        </button>
      </div>
    );
  }

  const openFlyout = (group: ToolGroup, el: HTMLElement) => {
    const rect = el.getBoundingClientRect();
    const estHeight = group.tools.length * 34 + 40;
    const top = Math.max(8, Math.min(rect.top, window.innerHeight - estHeight - 8));
    setOpenGroup((prev) => (prev?.id === group.id ? null : { id: group.id, top, left: rect.right + 6 }));
  };

  const isCursor = !activeTool || activeTool === 'cursor';
  const flyoutGroup = openGroup ? TOOL_GROUPS.find((g) => g.id === openGroup.id) : null;

  const utilBtn = (active: boolean, activeCls: string) =>
    `w-8 h-8 shrink-0 rounded-md flex items-center justify-center transition-colors cursor-pointer ${
      active ? activeCls : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D]'
    }`;

  return (
    <>
      <aside
        className="w-11 md:w-12 bg-[#131722] border-r border-[#2B2F3A] flex flex-col items-center py-1.5 gap-1 shrink-0 select-none z-30 overflow-y-auto overflow-x-hidden no-scrollbar"
        aria-label="Drawing Tools"
      >
        <button
          onClick={onToggleCollapse}
          className="w-8 h-6 shrink-0 rounded flex items-center justify-center text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D] transition-colors cursor-pointer"
          title="Collapse Drawing Toolbar"
        >
          <PanelLeftClose className="w-3.5 h-3.5" />
        </button>

        {/* Cursor (pan / select) */}
        <button
          onClick={() => onSelectTool(null)}
          title="Cursor — pan chart & select drawings (Esc)"
          className={`w-9 h-9 shrink-0 rounded-lg flex items-center justify-center transition-all cursor-pointer ${
            isCursor ? 'bg-[#2A2E39] text-[#2962FF]' : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D]'
          }`}
        >
          {getToolIcon('cursor')}
        </button>

        <div className="w-6 h-px bg-[#2B2F3A] my-0.5 shrink-0" />

        {/* Tool groups with flyouts */}
        {TOOL_GROUPS.map((group) => {
          const activeInGroup = group.tools.find(
            (t) => t.id === activeTool || (t.id === 'price_range' && activeTool === 'price_percentage_measure')
          );
          const shownTool: DrawingTool = activeInGroup?.id || lastTools[group.id] || group.tools[0].id;
          const isActive = !!activeInGroup;
          const isOpen = openGroup?.id === group.id;

          return (
            <div key={group.id} className="relative w-full flex justify-center shrink-0" data-group-trigger>
              <button
                onClick={(e) => {
                  if (longPressFiredRef.current) {
                    longPressFiredRef.current = false;
                    return;
                  }
                  setOpenGroup(null);
                  onSelectTool(isActive ? null : shownTool);
                  void e;
                }}
                onPointerDown={(e) => {
                  const el = e.currentTarget;
                  longPressFiredRef.current = false;
                  if (longPressRef.current) window.clearTimeout(longPressRef.current);
                  longPressRef.current = window.setTimeout(() => {
                    longPressFiredRef.current = true;
                    openFlyout(group, el);
                  }, 450);
                }}
                onPointerUp={() => {
                  if (longPressRef.current) window.clearTimeout(longPressRef.current);
                }}
                onPointerLeave={() => {
                  if (longPressRef.current) window.clearTimeout(longPressRef.current);
                }}
                onContextMenu={(e) => {
                  e.preventDefault();
                  openFlyout(group, e.currentTarget);
                }}
                title={`${getToolLabel(shownTool)} — long-press or ▸ for more ${group.label.toLowerCase()}`}
                className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all cursor-pointer touch-manipulation ${
                  isActive
                    ? 'bg-[#2962FF] text-white shadow-lg ring-2 ring-[#2962FF]/50'
                    : 'text-[#B2B5BE] hover:text-white hover:bg-[#1E222D]'
                }`}
              >
                {getToolIcon(shownTool)}
              </button>
              {/* Flyout trigger (the small arrow on TradingView) */}
              <button
                onClick={(e) => openFlyout(group, e.currentTarget.parentElement as HTMLElement)}
                title={`More ${group.label}`}
                className={`absolute right-0 md:right-0.5 top-0 h-9 w-2.5 flex items-end justify-center pb-1 cursor-pointer ${
                  isOpen ? 'text-[#2962FF]' : 'text-[#787B86] hover:text-white'
                }`}
              >
                <svg width="5" height="5" viewBox="0 0 5 5" className="fill-current">
                  <polygon points="0,5 5,5 5,0" />
                </svg>
              </button>
            </div>
          );
        })}

        <div className="w-6 h-px bg-[#2B2F3A] my-0.5 shrink-0" />

        <button
          onClick={onToggleMagnetMode}
          title={magnetMode ? 'Magnet Mode: ON (snaps to candle OHLC)' : 'Magnet Mode: OFF'}
          className={utilBtn(magnetMode, 'bg-[#089981]/20 text-[#089981] border border-[#089981]/50')}
        >
          <Magnet className="w-4 h-4" />
        </button>

        <button
          onClick={onToggleStayInDrawingMode}
          title={stayInDrawingMode ? 'Stay in Drawing Mode: ON' : 'Stay in Drawing Mode: OFF (returns to cursor after each drawing)'}
          className={utilBtn(stayInDrawingMode, 'bg-[#2962FF]/20 text-[#2962FF]')}
        >
          <PencilLine className="w-4 h-4" />
        </button>

        <button
          onClick={onToggleLockAll}
          title={isAllLocked ? 'Unlock All Drawings' : 'Lock All Drawings'}
          className={utilBtn(isAllLocked, 'bg-[#F59E0B]/20 text-[#F59E0B]')}
        >
          {isAllLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
        </button>

        <button
          onClick={onToggleHideAll}
          title={isAllHidden ? 'Show All Drawings' : 'Hide All Drawings'}
          className={utilBtn(isAllHidden, 'bg-[#F23645]/20 text-[#F23645]')}
        >
          {isAllHidden ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>

        <button
          onClick={onToggleFavoritesBar}
          title={showFavoritesBar ? 'Hide Favorites Toolbar' : 'Show Favorites Toolbar'}
          className={utilBtn(showFavoritesBar, 'bg-[#F59E0B]/15 text-[#F59E0B]')}
        >
          <Star className={`w-4 h-4 ${showFavoritesBar ? 'fill-current' : ''}`} />
        </button>

        <div className="flex flex-col gap-0.5 mt-auto shrink-0">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            title="Undo (Ctrl+Z)"
            className="w-8 h-6 rounded flex items-center justify-center text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D] disabled:opacity-25 disabled:pointer-events-none transition-colors cursor-pointer"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            title="Redo (Ctrl+Y)"
            className="w-8 h-6 rounded flex items-center justify-center text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D] disabled:opacity-25 disabled:pointer-events-none transition-colors cursor-pointer"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="w-6 h-px bg-[#2B2F3A] my-0.5 shrink-0" />

        <button onClick={onOpenSettings} title="Drawing Defaults & Colors" className={utilBtn(false, '')}>
          <Sliders className="w-4 h-4" />
        </button>

        <button
          onClick={() => {
            if (drawingsCount > 0 && window.confirm(`Remove all ${drawingsCount} drawings on this chart?`)) {
              onClearDrawings();
            }
          }}
          disabled={drawingsCount === 0}
          title={drawingsCount > 0 ? `Remove All ${drawingsCount} Drawings` : 'No active drawings'}
          className={`w-8 h-8 shrink-0 rounded flex items-center justify-center transition-colors ${
            drawingsCount > 0
              ? 'text-[#787B86] hover:text-[#F23645] hover:bg-[#1E222D] cursor-pointer'
              : 'text-[#787B86]/25 cursor-not-allowed'
          }`}
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </aside>

      {/* FLYOUT MENU (fixed so it is never clipped by the scrollable toolbar) */}
      {openGroup && flyoutGroup && (
        <div
          ref={flyoutRef}
          style={{ top: openGroup.top, left: openGroup.left }}
          className="fixed z-[60] min-w-60 bg-[#1E222D] border border-[#2B2F3A] rounded-lg shadow-2xl py-1 text-[#D1D4DC] select-none"
        >
          <div className="px-3 pt-1 pb-1.5 text-[10px] uppercase tracking-wider font-semibold text-[#787B86] border-b border-[#2B2F3A] mb-1">
            {flyoutGroup.label}
          </div>
          {flyoutGroup.tools.map((t) => {
            const isActive = activeTool === t.id || (t.id === 'price_range' && activeTool === 'price_percentage_measure');
            const isFav = favoriteTools.includes(t.id);
            return (
              <div
                key={t.id}
                className={`group flex items-center gap-2.5 px-3 h-8.5 text-xs cursor-pointer transition-colors ${
                  isActive ? 'bg-[#2962FF]/20 text-white' : 'hover:bg-[#2A2E39]'
                }`}
                onClick={() => {
                  onSelectTool(t.id);
                  setOpenGroup(null);
                }}
              >
                <span className={isActive ? 'text-[#2962FF]' : 'text-[#B2B5BE]'}>{getToolIcon(t.id)}</span>
                <span className="flex-1 whitespace-nowrap">{t.label}</span>
                {t.shortcut && <span className="text-[10px] text-[#787B86] font-mono hidden md:inline">{t.shortcut}</span>}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite?.(t.id);
                  }}
                  title={isFav ? 'Remove from favorites' : 'Add to favorites'}
                  className={`p-1 rounded cursor-pointer ${
                    isFav ? 'text-[#F59E0B]' : 'text-[#787B86] md:opacity-0 md:group-hover:opacity-100 hover:text-[#F59E0B]'
                  }`}
                >
                  <Star className={`w-3.5 h-3.5 ${isFav ? 'fill-current' : ''}`} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
};
