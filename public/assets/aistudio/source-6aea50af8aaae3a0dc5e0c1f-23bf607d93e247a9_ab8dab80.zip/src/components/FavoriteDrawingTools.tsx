import React, { useRef } from 'react';
import {
  DrawingTool,
} from '../types';
import { GripHorizontal, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { getToolIcon, getToolLabel } from './drawingTools';

interface FavoriteDrawingToolsProps {
  favoriteTools: DrawingTool[];
  activeTool: DrawingTool | null;
  onSelectTool: (tool: DrawingTool) => void;
  onRemoveFavorite: (tool: DrawingTool) => void;
  onMoveFavorite: (index: number, direction: 'left' | 'right') => void;
}

export { getToolIcon, getToolLabel };

export const FavoriteDrawingTools: React.FC<FavoriteDrawingToolsProps> = ({
  favoriteTools,
  activeTool,
  onSelectTool,
  onRemoveFavorite,
  onMoveFavorite,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const dragOffsetRef = useRef({ x: 0, y: 0 });

  if (favoriteTools.length === 0) return null;

  const handleStartDrag = (clientX: number, clientY: number) => {
    if (!containerRef.current) return;
    isDraggingRef.current = true;
    const rect = containerRef.current.getBoundingClientRect();
    dragOffsetRef.current = {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };

    const handleMove = (moveX: number, moveY: number) => {
      if (!isDraggingRef.current || !containerRef.current) return;
      const x = Math.max(10, Math.min(window.innerWidth - 300, moveX - dragOffsetRef.current.x));
      const y = Math.max(50, Math.min(window.innerHeight - 80, moveY - dragOffsetRef.current.y));
      containerRef.current.style.left = `${x}px`;
      containerRef.current.style.top = `${y}px`;
      containerRef.current.style.bottom = 'auto';
      containerRef.current.style.transform = 'none';
    };

    const handleMouseMove = (moveEvent: MouseEvent) => {
      handleMove(moveEvent.clientX, moveEvent.clientY);
    };

    const handleTouchMove = (touchEvent: TouchEvent) => {
      if (touchEvent.touches.length > 0) {
        handleMove(touchEvent.touches[0].clientX, touchEvent.touches[0].clientY);
      }
    };

    const handleEndDrag = () => {
      isDraggingRef.current = false;
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleEndDrag);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleEndDrag);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleEndDrag);
    window.addEventListener('touchmove', handleTouchMove, { passive: true });
    window.addEventListener('touchend', handleEndDrag);
  };

  return (
    <div
      ref={containerRef}
      style={{ bottom: '24px', left: '72px' }}
      className="fixed z-35 flex items-center gap-1 p-1 bg-[#1E222D]/95 border border-[#2B2F3A] rounded-lg shadow-xl backdrop-blur-md select-none text-[#D1D4DC]"
    >
      {/* Drag handle */}
      <div
        onMouseDown={(e) => handleStartDrag(e.clientX, e.clientY)}
        onTouchStart={(e) => {
          if (e.touches[0]) handleStartDrag(e.touches[0].clientX, e.touches[0].clientY);
        }}
        className="px-1 py-1 cursor-grab active:cursor-grabbing text-[#787B86] hover:text-[#D1D4DC] touch-none"
        title="Drag Favorites Bar"
      >
        <GripHorizontal className="w-3.5 h-3.5" />
      </div>

      <div className="w-px h-5 bg-[#2B2F3A] mx-0.5" />

      {/* Tool icons with reorder & quick removal */}
      <div className="flex items-center gap-1 overflow-x-auto max-w-[70vw] no-scrollbar">
        {favoriteTools.map((tool, idx) => {
          const isActive = activeTool === tool;
          return (
            <div key={tool} className="relative group flex items-center">
              <button
                onClick={() => onSelectTool(tool)}
                className={`p-1.5 rounded flex items-center justify-center transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-[#2962FF] text-white shadow-xs'
                    : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39]'
                }`}
                title={getToolLabel(tool)}
              >
                {getToolIcon(tool)}
              </button>

              {/* Hover actions: Move Left, Move Right, Remove */}
              <div className="absolute -top-7 left-1/2 -translate-x-1/2 hidden group-hover:flex items-center gap-0.5 bg-[#181B24] border border-[#2B2F3A] rounded px-1 py-0.5 shadow-lg z-50">
                {idx > 0 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveFavorite(idx, 'left');
                    }}
                    className="p-0.5 text-[#787B86] hover:text-white"
                    title="Move Left"
                  >
                    <ChevronLeft className="w-3 h-3" />
                  </button>
                )}
                {idx < favoriteTools.length - 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveFavorite(idx, 'right');
                    }}
                    className="p-0.5 text-[#787B86] hover:text-white"
                    title="Move Right"
                  >
                    <ChevronRight className="w-3 h-3" />
                  </button>
                )}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemoveFavorite(tool);
                  }}
                  className="p-0.5 text-[#787B86] hover:text-[#F23645]"
                  title="Remove from favorites"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
