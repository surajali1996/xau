import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Share2, X, Smartphone } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running inside standalone PWA mode, suppress install button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded bg-[#2962FF] hover:bg-[#1e53e5] text-white shadow-xs transition-colors cursor-pointer"
        title="Install Binance Futures Pro PWA"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Install App</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded bg-[#1E222D] hover:bg-[#2A2E39] border border-[#2B2F3A] text-[#D1D4DC] transition-colors cursor-pointer"
          title="Install on iPhone / iPad"
        >
          <Smartphone className="w-3.5 h-3.5 text-[#2962FF]" />
          <span className="hidden sm:inline">Install PWA</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs">
            <div className="w-full max-w-sm rounded-xl bg-[#1E222D] border border-[#2B2F3A] p-5 shadow-2xl text-[#D1D4DC]">
              <div className="flex items-center justify-between pb-3 border-b border-[#2B2F3A]">
                <h3 className="font-semibold text-white text-sm flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-[#2962FF]" />
                  Install on iPhone / iPad
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded text-[#787B86] hover:text-white hover:bg-[#2A2E39]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="mt-3 text-xs space-y-2.5 text-[#A0A4AE]">
                <p className="flex items-start gap-2">
                  <span className="font-bold text-[#2962FF]">1.</span>
                  <span>Tap the <strong className="text-white">Share</strong> button <Share2 className="w-3.5 h-3.5 inline mx-0.5 text-[#2962FF]" /> in Safari toolbar.</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="font-bold text-[#2962FF]">2.</span>
                  <span>Scroll down and select <strong className="text-white">Add to Home Screen</strong>.</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="font-bold text-[#2962FF]">3.</span>
                  <span>Launch from your home screen for full standalone trading experience.</span>
                </p>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full rounded-lg bg-[#2962FF] py-2 text-xs font-semibold text-white hover:bg-[#1e53e5] transition-colors"
              >
                Got It
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
