import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  createChart,
  IChartApi,
  ISeriesApi,
  ColorType,
  CrosshairMode,
  LineStyle,
  PriceScaleMode,
  IPriceLine,
  CandlestickSeries,
  HistogramSeries,
  UTCTimestamp,
} from 'lightweight-charts';
import {
  CandleData,
  PriceType,
  DrawingTool,
  DrawingItem,
  DrawingPoint,
  PriceAlert,
  ReplayState,
  OHLCData,
  DrawingSettings,
} from '../types';
import {
  BinanceStreamManager,
  fetchHistoricalKlines,
  parseIntervalToMinutes,
} from '../services/binanceService';
import { alertEngine } from '../services/alertEngine';
import {
  Maximize2,
  Minimize2,
  RefreshCw,
  Camera,
  PlusCircle,
  Bell,
  Clock,
  Sparkles,
  Plus,
  Trash2,
  Pencil,
  Check,
  Rewind,
  Copy,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  Percent,
} from 'lucide-react';

interface TradingChartProps {
  symbol: string;
  interval: string;
  priceType: PriceType;
  onChangePriceType: (type: PriceType) => void;
  onChangeInterval: (interval: string) => void;
  activeDrawingTool: DrawingTool;
  onResetDrawingTool: () => void;
  drawings: DrawingItem[];
  onAddDrawing: (drawing: DrawingItem) => void;
  onUpdateDrawing: (drawing: DrawingItem) => void;
  onDeleteDrawing: (id: string) => void;
  onClearDrawings: () => void;
  drawingSettings: DrawingSettings;
  onOpenSettingsModal?: () => void;
  replayState: ReplayState;
  onSelectCutoffCandle: (candle: CandleData) => void;
  onOpenAlertModal: (price?: number) => void;
  alerts: PriceAlert[];
  onAlertsChanged: () => void;
  onOpenCustomTimeframe: () => void;
  magnetMode: boolean;
  onToggleReplay: () => void;
}

export const TradingChart: React.FC<TradingChartProps> = ({
  symbol,
  interval,
  priceType,
  onChangePriceType,
  onChangeInterval,
  activeDrawingTool,
  onResetDrawingTool,
  drawings,
  onAddDrawing,
  onUpdateDrawing,
  onDeleteDrawing,
  drawingSettings,
  onOpenSettingsModal,
  replayState,
  onSelectCutoffCandle,
  onOpenAlertModal,
  alerts,
  onAlertsChanged,
  onOpenCustomTimeframe,
  magnetMode,
  onToggleReplay,
}) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const overlaySvgRef = useRef<SVGSVGElement>(null);
  const contextMenuRef = useRef<HTMLDivElement>(null);
  const drawingContextMenuRef = useRef<HTMLDivElement>(null);

  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const streamManagerRef = useRef<BinanceStreamManager | null>(null);
  const priceLinesMapRef = useRef<Map<string, IPriceLine>>(new Map());

  // Data cache
  const fullCandlesRef = useRef<CandleData[]>([]);
  const activeCandleRef = useRef<CandleData | null>(null);

  // Chart HUD & States
  const [ohlcHud, setOhlcHud] = useState<OHLCData | null>(null);
  const [countdownText, setCountdownText] = useState<string>('--:--');
  const [activePriceY, setActivePriceY] = useState<number | null>(null);
  const [isLogScale, setIsLogScale] = useState<boolean>(false);
  const [isAutoScale, setIsAutoScale] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Crosshair coordinates
  const [crosshairPos, setCrosshairPos] = useState<{ x: number; y: number; price: number } | null>(null);

  // Chart context menu state
  const [showRightClickMenu, setShowRightClickMenu] = useState<{
    x: number;
    y: number;
    price: number;
  } | null>(null);

  // Drawing context menu state
  const [drawingContextMenu, setDrawingContextMenu] = useState<{
    x: number;
    y: number;
    drawing: DrawingItem;
  } | null>(null);

  // Dragging alert state
  const [draggingAlert, setDraggingAlert] = useState<{
    id: string;
    currentPrice: number;
  } | null>(null);

  // Drawing creation state
  const [creationPoints, setCreationPoints] = useState<DrawingPoint[]>([]);
  const [activeBrushPoints, setActiveBrushPoints] = useState<DrawingPoint[]>([]);
  const [isBrushDrawing, setIsBrushDrawing] = useState<boolean>(false);
  const [currentMouseCoord, setCurrentMouseCoord] = useState<{ x: number; y: number } | null>(null);

  // Selected drawing state for moving, resizing, and styling
  const [selectedDrawingId, setSelectedDrawingId] = useState<string | null>(null);

  // Dragging / resizing an existing drawing
  const [draggingHandle, setDraggingHandle] = useState<{
    drawingId: string;
    pointIndex: number;
  } | null>(null);

  const [draggingWholeDrawing, setDraggingWholeDrawing] = useState<{
    drawingId: string;
    startPoint: DrawingPoint;
    initialPoints: DrawingPoint[];
  } | null>(null);

  // Prevent event conflicts / debounce
  const drawCooldownRef = useRef<number>(0);
  const activePointerIdRef = useRef<number | null>(null);

  // Reset creation points when activeDrawingTool reverts to 'cursor'
  useEffect(() => {
    if (activeDrawingTool === 'cursor') {
      setCreationPoints([]);
      setActiveBrushPoints([]);
      setIsBrushDrawing(false);
    }
  }, [activeDrawingTool]);

  // SMART AUTO-CLOSING CONTEXT MENU (Both empty canvas menu and drawing context menu)
  useEffect(() => {
    if (!showRightClickMenu && !drawingContextMenu) return;

    // Android hardware / swipe Back button integration
    try {
      window.history.pushState({ ctxMenuOpen: true }, '');
    } catch {
      // Ignore
    }

    const handlePopState = () => {
      setShowRightClickMenu(null);
      setDrawingContextMenu(null);
    };

    const handlePointerDownOutside = (e: PointerEvent | MouseEvent) => {
      if (
        contextMenuRef.current &&
        !contextMenuRef.current.contains(e.target as Node)
      ) {
        setShowRightClickMenu(null);
      }
      if (
        drawingContextMenuRef.current &&
        !drawingContextMenuRef.current.contains(e.target as Node)
      ) {
        setDrawingContextMenu(null);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowRightClickMenu(null);
        setDrawingContextMenu(null);
      }
    };

    window.addEventListener('pointerdown', handlePointerDownOutside, true);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('pointerdown', handlePointerDownOutside, true);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('popstate', handlePopState);
    };
  }, [showRightClickMenu, drawingContextMenu]);

  // KEYBOARD SHORTCUTS (Delete/Backspace to delete selected drawing, Escape to deselect)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Delete' || e.key === 'Backspace') {
        const activeTag = document.activeElement?.tagName.toLowerCase();
        if (activeTag === 'input' || activeTag === 'textarea') return;

        if (selectedDrawingId) {
          onDeleteDrawing(selectedDrawingId);
          setSelectedDrawingId(null);
        }
      }
      if (e.key === 'Escape') {
        if (creationPoints.length > 0) {
          setCreationPoints([]);
        }
        if (activeDrawingTool !== 'cursor') {
          onResetDrawingTool();
        }
        setSelectedDrawingId(null);
        setShowRightClickMenu(null);
        setDrawingContextMenu(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [selectedDrawingId, creationPoints, activeDrawingTool, onDeleteDrawing, onResetDrawingTool]);

  // Live countdown timer calculation loop
  useEffect(() => {
    const updateCountdown = () => {
      const active = activeCandleRef.current;
      if (!active) {
        setCountdownText('--:--');
        return;
      }

      const now = Date.now();
      let closeMs = active.closeTimeMs;
      if (!closeMs) {
        const minutes = parseIntervalToMinutes(interval);
        closeMs = (active.time + minutes * 60) * 1000 - 1;
      }

      const diffMs = Math.max(0, closeMs - now);
      const totalSec = Math.floor(diffMs / 1000);
      const hours = Math.floor(totalSec / 3600);
      const mins = Math.floor((totalSec % 3600) / 60);
      const secs = totalSec % 60;

      if (hours > 0) {
        setCountdownText(
          `${hours}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
        );
      } else {
        setCountdownText(
          `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
        );
      }

      if (candleSeriesRef.current && active.close) {
        const y = candleSeriesRef.current.priceToCoordinate(active.close);
        setActivePriceY(y);
      }
    };

    updateCountdown();
    const timer = setInterval(updateCountdown, 1000);
    return () => clearInterval(timer);
  }, [interval]);

  // Magnet mode helper to snap anchors to candle OHLC values
  const applyMagnet = useCallback(
    (rawTime: number, rawPrice: number): { time: number; price: number } => {
      if (!magnetMode || fullCandlesRef.current.length === 0) {
        return { time: rawTime, price: rawPrice };
      }

      const closestCandle = fullCandlesRef.current.reduce((prev, curr) =>
        Math.abs(curr.time - rawTime) < Math.abs(prev.time - rawTime) ? curr : prev
      );
      if (!closestCandle) return { time: rawTime, price: rawPrice };

      const candidates = [closestCandle.open, closestCandle.high, closestCandle.low, closestCandle.close];
      const closestPrice = candidates.reduce((prev, curr) =>
        Math.abs(curr - rawPrice) < Math.abs(prev - rawPrice) ? curr : prev
      );

      return { time: closestCandle.time, price: closestPrice };
    },
    [magnetMode]
  );

  // Initialize TradingView Lightweight Chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    chartContainerRef.current.innerHTML = '';
    streamManagerRef.current = new BinanceStreamManager();

    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: chartContainerRef.current.clientHeight,
      layout: {
        background: { type: ColorType.Solid, color: '#131722' },
        textColor: '#787B86',
        fontSize: 11,
        fontFamily: "'JetBrains Mono', 'Plus Jakarta Sans', monospace, sans-serif",
      },
      grid: {
        vertLines: { color: '#1E222D', style: LineStyle.Solid },
        horzLines: { color: '#1E222D', style: LineStyle.Solid },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: {
          color: '#787B86',
          width: 1,
          style: LineStyle.Dashed,
          labelBackgroundColor: '#2A2E39',
        },
        horzLine: {
          color: '#787B86',
          width: 1,
          style: LineStyle.Dashed,
          labelBackgroundColor: '#2A2E39',
        },
      },
      rightPriceScale: {
        borderColor: '#2B2F3A',
        autoScale: true,
        scaleMargins: {
          top: 0.08,
          bottom: 0.18,
        },
        visible: true,
        entireTextOnly: true,
      },
      timeScale: {
        borderColor: '#2B2F3A',
        timeVisible: true,
        secondsVisible: false,
        shiftVisibleRangeOnNewBar: true,
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: true,
      },
      handleScale: {
        axisPressedMouseMove: { time: true, price: true },
        mouseWheel: true,
        pinch: true,
      },
    });

    chartRef.current = chart;

    // Candlestick Series (#089981 Up, #F23645 Down)
    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#089981',
      downColor: '#F23645',
      borderVisible: true,
      borderColor: '#378658',
      borderUpColor: '#089981',
      borderDownColor: '#F23645',
      wickVisible: true,
      wickUpColor: '#089981',
      wickDownColor: '#F23645',
      priceFormat: {
        type: 'price',
        precision: 4,
        minMove: 0.0001,
      },
    });
    candleSeriesRef.current = candlestickSeries;

    // Volume Histogram
    const volumeSeries = chart.addSeries(HistogramSeries, {
      color: '#26a69a',
      priceFormat: { type: 'volume' },
      priceScaleId: 'volume_scale',
    });
    chart.priceScale('volume_scale').applyOptions({
      scaleMargins: {
        top: 0.82,
        bottom: 0,
      },
      visible: false,
    });
    volumeSeriesRef.current = volumeSeries;

    // Crosshair move listener for HUD & scale coordinates
    chart.subscribeCrosshairMove((param) => {
      if (!param || !param.point || !candleSeriesRef.current) {
        setCrosshairPos(null);
        const active = activeCandleRef.current;
        if (active) {
          const change = active.close - active.open;
          const changePercent = active.open !== 0 ? (change / active.open) * 100 : 0;
          setOhlcHud({
            open: active.open,
            high: active.high,
            low: active.low,
            close: active.close,
            volume: active.volume,
            change,
            changePercent,
            time: active.time,
          });
        }
        return;
      }

      const price = candleSeriesRef.current.coordinateToPrice(param.point.y);
      if (price !== null) {
        setCrosshairPos({
          x: param.point.x,
          y: param.point.y,
          price,
        });
      }

      const candleData = param.seriesData.get(candleSeriesRef.current) as {
        open: number;
        high: number;
        low: number;
        close: number;
        time: number;
      } | undefined;

      const volData = param.seriesData.get(volumeSeries) as { value: number } | undefined;

      if (candleData) {
        const change = candleData.close - candleData.open;
        const changePercent = candleData.open !== 0 ? (change / candleData.open) * 100 : 0;
        setOhlcHud({
          open: candleData.open,
          high: candleData.high,
          low: candleData.low,
          close: candleData.close,
          volume: volData?.value || 0,
          change,
          changePercent,
          time: candleData.time,
        });
      }
    });

    // Resize observer
    const handleResize = () => {
      if (chartContainerRef.current && chart) {
        chart.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: chartContainerRef.current.clientHeight,
        });
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      streamManagerRef.current?.destroy();
      chart.remove();
      chartRef.current = null;
      candleSeriesRef.current = null;
      volumeSeriesRef.current = null;
    };
  }, []);

  // Fetch Klines and Subscribe to Binance WebSocket
  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    const loadDataAndStream = async () => {
      try {
        let prevRange: any = null;
        if (chartRef.current) {
          prevRange = chartRef.current.timeScale().getVisibleLogicalRange();
        }

        const candles = await fetchHistoricalKlines(symbol, interval, priceType, 1000);
        if (!isMounted) return;

        fullCandlesRef.current = candles;

        if (candles.length > 0) {
          const lastCandle = candles[candles.length - 1];
          activeCandleRef.current = lastCandle;

          const change = lastCandle.close - lastCandle.open;
          const changePercent = lastCandle.open !== 0 ? (change / lastCandle.open) * 100 : 0;
          setOhlcHud({
            open: lastCandle.open,
            high: lastCandle.high,
            low: lastCandle.low,
            close: lastCandle.close,
            volume: lastCandle.volume,
            change,
            changePercent,
            time: lastCandle.time,
          });

          // Set chart candle series
          const formattedCandles = candles.map((c) => ({
            time: c.time as UTCTimestamp,
            open: c.open,
            high: c.high,
            low: c.low,
            close: c.close,
          }));
          candleSeriesRef.current?.setData(formattedCandles);

          // Set volume series
          const formattedVolumes = candles.map((c) => ({
            time: c.time as UTCTimestamp,
            value: c.volume,
            color: c.close >= c.open ? '#08998140' : '#F2364540',
          }));
          volumeSeriesRef.current?.setData(formattedVolumes);

          // Maintain zoom position
          if (prevRange && chartRef.current) {
            chartRef.current.timeScale().setVisibleLogicalRange(prevRange);
          } else {
            chartRef.current?.timeScale().fitContent();
          }

          streamManagerRef.current?.setActiveCandle(lastCandle);
        }

        setIsLoading(false);

        // Connect real-time WebSocket & Tick Stream
        if (streamManagerRef.current) {
          streamManagerRef.current.subscribe(
            symbol,
            interval,
            priceType,
            (updatedCandle, isClosed) => {
              if (replayState.isActive) return;

              activeCandleRef.current = updatedCandle;

              // Live candle movement update
              candleSeriesRef.current?.update({
                time: updatedCandle.time as UTCTimestamp,
                open: updatedCandle.open,
                high: updatedCandle.high,
                low: updatedCandle.low,
                close: updatedCandle.close,
              });

              volumeSeriesRef.current?.update({
                time: updatedCandle.time as UTCTimestamp,
                value: updatedCandle.volume,
                color: updatedCandle.close >= updatedCandle.open ? '#08998140' : '#F2364540',
              });

              const y = candleSeriesRef.current?.priceToCoordinate(updatedCandle.close);
              if (y !== undefined) setActivePriceY(y);

              const change = updatedCandle.close - updatedCandle.open;
              const changePercent = updatedCandle.open !== 0 ? (change / updatedCandle.open) * 100 : 0;
              setOhlcHud({
                open: updatedCandle.open,
                high: updatedCandle.high,
                low: updatedCandle.low,
                close: updatedCandle.close,
                volume: updatedCandle.volume,
                change,
                changePercent,
                time: updatedCandle.time,
              });

              if (isClosed) {
                fullCandlesRef.current.push(updatedCandle);
              }
            },
            (tickPrice, tickPriceType) => {
              if (replayState.isActive) return;
              alertEngine.checkTick(tickPrice, symbol, tickPriceType);
            }
          );
        }
      } catch {
        if (isMounted) setIsLoading(false);
      }
    };

    loadDataAndStream();

    return () => {
      isMounted = false;
    };
  }, [symbol, interval, priceType]);

  // Handle Bar Replay slicing
  useEffect(() => {
    if (!candleSeriesRef.current || !volumeSeriesRef.current) return;

    if (replayState.isActive) {
      streamManagerRef.current?.setPaused(true);

      const replayBars = replayState.allCandles.slice(0, replayState.currentIndex + 1);
      if (replayBars.length > 0) {
        const last = replayBars[replayBars.length - 1];
        activeCandleRef.current = last;

        candleSeriesRef.current.setData(
          replayBars.map((c) => ({
            time: c.time as UTCTimestamp,
            open: c.open,
            high: c.high,
            low: c.low,
            close: c.close,
          }))
        );

        volumeSeriesRef.current.setData(
          replayBars.map((c) => ({
            time: c.time as UTCTimestamp,
            value: c.volume,
            color: c.close >= c.open ? '#08998140' : '#F2364540',
          }))
        );
      }
    } else {
      streamManagerRef.current?.setPaused(false);
      if (fullCandlesRef.current.length > 0) {
        candleSeriesRef.current.setData(
          fullCandlesRef.current.map((c) => ({
            time: c.time as UTCTimestamp,
            open: c.open,
            high: c.high,
            low: c.low,
            close: c.close,
          }))
        );
        volumeSeriesRef.current.setData(
          fullCandlesRef.current.map((c) => ({
            time: c.time as UTCTimestamp,
            value: c.volume,
            color: c.close >= c.open ? '#08998140' : '#F2364540',
          }))
        );
      }
    }
  }, [replayState.isActive, replayState.currentIndex]);

  // Sync Price Alert lines on series
  useEffect(() => {
    if (!candleSeriesRef.current) return;
    const series = candleSeriesRef.current;

    priceLinesMapRef.current.forEach((line, alertId) => {
      const exists = alerts.some((a) => a.id === alertId && a.status === 'active' && a.symbol === symbol);
      if (!exists) {
        series.removePriceLine(line);
        priceLinesMapRef.current.delete(alertId);
      }
    });

    alerts
      .filter((a) => a.symbol === symbol && a.status === 'active')
      .forEach((alert) => {
        let priceLine = priceLinesMapRef.current.get(alert.id);
        const displayPrice = draggingAlert?.id === alert.id ? draggingAlert.currentPrice : alert.price;

        if (!priceLine) {
          priceLine = series.createPriceLine({
            price: displayPrice,
            color: '#F23645',
            lineWidth: 1,
            lineStyle: LineStyle.Dashed,
            axisLabelVisible: true,
            title: `Alert (${displayPrice.toFixed(2)})`,
          });
          priceLinesMapRef.current.set(alert.id, priceLine);
        } else {
          priceLine.applyOptions({
            price: displayPrice,
            title: `Alert (${displayPrice.toFixed(2)})`,
          });
        }
      });
  }, [alerts, symbol, draggingAlert]);

  // Draggable Alert Handler (Free moving)
  const handleAlertMouseDown = (alertId: string, initialPrice: number, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    let latestPrice = initialPrice;
    setDraggingAlert({ id: alertId, currentPrice: initialPrice });

    const handleMouseMove = (moveEvent: MouseEvent) => {
      if (!chartContainerRef.current || !candleSeriesRef.current) return;
      const rect = chartContainerRef.current.getBoundingClientRect();
      const y = moveEvent.clientY - rect.top;
      const newPrice = candleSeriesRef.current.coordinateToPrice(y);
      if (newPrice !== null && newPrice > 0) {
        latestPrice = newPrice;
        setDraggingAlert({ id: alertId, currentPrice: newPrice });
      }
    };

    const handleMouseUp = () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      setDraggingAlert(null);
      alertEngine.updateAlertPrice(alertId, latestPrice);
      onAlertsChanged();
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  // Convert time & price to SVG coordinates
  const getCoordinates = useCallback(
    (point: { time: number; price: number }): { x: number; y: number } | null => {
      if (!chartRef.current || !candleSeriesRef.current) return null;
      const x = chartRef.current.timeScale().timeToCoordinate(point.time as UTCTimestamp);
      const y = candleSeriesRef.current.priceToCoordinate(point.price);
      if (x === null || y === null) return null;
      return { x: Number(x), y: Number(y) };
    },
    []
  );

  // Helper to complete a drawing in SINGLE DRAWING MODE
  const completeDrawing = useCallback(
    (newDrawing: DrawingItem) => {
      onAddDrawing(newDrawing);
      setSelectedDrawingId(newDrawing.id);
      setCreationPoints([]);
      setActiveBrushPoints([]);
      setIsBrushDrawing(false);
      drawCooldownRef.current = Date.now() + 300;
      // TRADINGVIEW SINGLE DRAW MODE: automatically revert to cursor mode
      onResetDrawingTool();
    },
    [onAddDrawing, onResetDrawingTool]
  );

  // Canvas Pointer Down: Supports mouse, stylus & Android touch gestures
  const handleCanvasPointerDown = (e: React.PointerEvent<any>) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    if (Date.now() < drawCooldownRef.current) return;

    if (!chartRef.current || !candleSeriesRef.current || !chartContainerRef.current) return;

    // Track active pointer to prevent duplicate simultaneous touches
    if (activePointerIdRef.current !== null && activePointerIdRef.current !== e.pointerId) return;
    activePointerIdRef.current = e.pointerId;

    const rect = chartContainerRef.current.getBoundingClientRect();
    const rawX = e.clientX - rect.left;
    const rawY = e.clientY - rect.top;

    const rawTime = chartRef.current.timeScale().coordinateToTime(rawX) as number | null;
    const rawPrice = candleSeriesRef.current.coordinateToPrice(rawY);

    if (rawTime === null || rawPrice === null) return;

    // Apply Magnet Mode
    const { time, price } = applyMagnet(rawTime, rawPrice);

    // Bar Replay Cutoff Selection
    if (replayState.isSelectingCutoff) {
      const closest = fullCandlesRef.current.reduce((prev, curr) =>
        Math.abs(curr.time - time) < Math.abs(prev.time - time) ? curr : prev
      );
      if (closest) onSelectCutoffCandle(closest);
      return;
    }

    // Default Cursor mode: Deselect if tapped on empty canvas
    if (activeDrawingTool === 'cursor') {
      setSelectedDrawingId(null);
      return;
    }

    // Freehand Brush Tool
    if (activeDrawingTool === 'brush') {
      setIsBrushDrawing(true);
      setActiveBrushPoints([{ time, price }]);
      return;
    }

    // Single-Point Tools
    if (activeDrawingTool === 'horizontal_line') {
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'horizontal_line',
        points: [{ time, price }],
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
        lineStyle: drawingSettings.lineStyle,
        extendLeft: drawingSettings.extendLeft,
        extendRight: drawingSettings.extendRight,
      });
      return;
    }

    if (activeDrawingTool === 'horizontal_ray') {
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'horizontal_ray',
        points: [{ time, price }],
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
        lineStyle: drawingSettings.lineStyle,
        extendRight: true,
      });
      return;
    }

    if (activeDrawingTool === 'vertical_line') {
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'vertical_line',
        points: [{ time, price }],
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
        lineStyle: drawingSettings.lineStyle,
      });
      return;
    }

    if (activeDrawingTool === 'cross_line') {
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'cross_line',
        points: [{ time, price }],
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
        lineStyle: drawingSettings.lineStyle,
      });
      return;
    }

    if (activeDrawingTool === 'text') {
      const textVal = window.prompt('Enter Text Note:', 'Key Level / Note') || 'Note';
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'text',
        points: [{ time, price }],
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
        fontSize: drawingSettings.fontSize || 14,
        text: textVal,
      });
      return;
    }

    if (activeDrawingTool === 'price_label') {
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'price_label',
        points: [{ time, price }],
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
        fontSize: drawingSettings.fontSize || 12,
      });
      return;
    }

    if (activeDrawingTool === 'arrow_marker') {
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'arrow_marker',
        points: [{ time, price }],
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
      });
      return;
    }

    // Polyline tool: sequentially add points, completed on double-click
    if (activeDrawingTool === 'polyline') {
      if (creationPoints.length > 0 && e.detail >= 2) {
        completeDrawing({
          id: 'drawing_' + Date.now(),
          tool: 'polyline',
          points: creationPoints,
          color: drawingSettings.color,
          lineWidth: drawingSettings.lineWidth,
          lineStyle: drawingSettings.lineStyle,
        });
        return;
      }
      setCreationPoints((prev) => [...prev, { time, price }]);
      return;
    }

    // Two-Point Tools
    const twoPointTools: DrawingTool[] = [
      'trendline',
      'ray',
      'extended_line',
      'arrow',
      'rectangle',
      'circle',
      'ellipse',
      'fibonacci',
      'fibonacci_timezones',
      'price_range',
      'date_and_price_range',
      'date_range',
      'price_percentage_measure',
    ];

    if (twoPointTools.includes(activeDrawingTool)) {
      if (creationPoints.length === 0) {
        setCreationPoints([{ time, price }]);
      } else {
        completeDrawing({
          id: 'drawing_' + Date.now(),
          tool: activeDrawingTool,
          points: [creationPoints[0], { time, price }],
          color: drawingSettings.color,
          lineWidth: drawingSettings.lineWidth,
          lineStyle: drawingSettings.lineStyle,
          extendLeft: activeDrawingTool === 'extended_line' ? true : drawingSettings.extendLeft,
          extendRight:
            activeDrawingTool === 'extended_line' || activeDrawingTool === 'ray'
              ? true
              : drawingSettings.extendRight,
          fillColor: drawingSettings.fillColor || drawingSettings.color,
          fillOpacity: drawingSettings.fillOpacity,
        });
      }
      return;
    }

    // Three-Point Tools (Parallel Channel, Fibonacci Extension, Fibonacci Channel)
    const threePointTools: DrawingTool[] = [
      'parallel_channel',
      'fibonacci_extension',
      'fibonacci_channel',
    ];

    if (threePointTools.includes(activeDrawingTool)) {
      if (creationPoints.length === 0) {
        setCreationPoints([{ time, price }]);
      } else if (creationPoints.length === 1) {
        setCreationPoints([creationPoints[0], { time, price }]);
      } else if (creationPoints.length === 2) {
        completeDrawing({
          id: 'drawing_' + Date.now(),
          tool: activeDrawingTool,
          points: [creationPoints[0], creationPoints[1], { time, price }],
          color: drawingSettings.color,
          lineWidth: drawingSettings.lineWidth,
          lineStyle: drawingSettings.lineStyle,
          fillColor: drawingSettings.fillColor || drawingSettings.color,
          fillOpacity: drawingSettings.fillOpacity,
        });
      }
      return;
    }
  };

  // Canvas Pointer Move
  const handleCanvasPointerMove = (e: React.PointerEvent<any>) => {
    if (!chartContainerRef.current) return;
    const rect = chartContainerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setCurrentMouseCoord({ x, y });

    // Brush drawing in progress
    if (isBrushDrawing && chartRef.current && candleSeriesRef.current) {
      const time = chartRef.current.timeScale().coordinateToTime(x) as number | null;
      const price = candleSeriesRef.current.coordinateToPrice(y);
      if (time !== null && price !== null) {
        setActiveBrushPoints((prev) => [...prev, { time, price }]);
      }
      return;
    }

    // Dragging a specific point handle of a selected drawing
    if (draggingHandle && chartRef.current && candleSeriesRef.current) {
      const time = chartRef.current.timeScale().coordinateToTime(x) as number | null;
      const price = candleSeriesRef.current.coordinateToPrice(y);
      if (time !== null && price !== null) {
        const targetDrawing = drawings.find((d) => d.id === draggingHandle.drawingId);
        if (targetDrawing && !targetDrawing.locked) {
          const updatedPoints = [...targetDrawing.points];
          updatedPoints[draggingHandle.pointIndex] = { time, price };
          onUpdateDrawing({ ...targetDrawing, points: updatedPoints });
        }
      }
      return;
    }

    // Dragging an entire drawing body
    if (draggingWholeDrawing && chartRef.current && candleSeriesRef.current) {
      const time = chartRef.current.timeScale().coordinateToTime(x) as number | null;
      const price = candleSeriesRef.current.coordinateToPrice(y);
      if (time !== null && price !== null) {
        const targetDrawing = drawings.find((d) => d.id === draggingWholeDrawing.drawingId);
        if (targetDrawing && !targetDrawing.locked) {
          const deltaTime = time - draggingWholeDrawing.startPoint.time;
          const deltaPrice = price - draggingWholeDrawing.startPoint.price;
          const shiftedPoints = draggingWholeDrawing.initialPoints.map((pt) => ({
            time: pt.time + deltaTime,
            price: pt.price + deltaPrice,
          }));
          onUpdateDrawing({ ...targetDrawing, points: shiftedPoints });
        }
      }
    }
  };

  // Canvas Pointer Up
  const handleCanvasPointerUp = () => {
    activePointerIdRef.current = null;

    if (isBrushDrawing && activeBrushPoints.length > 1) {
      completeDrawing({
        id: 'drawing_' + Date.now(),
        tool: 'brush',
        points: activeBrushPoints.slice(0, 2),
        brushPoints: activeBrushPoints,
        color: drawingSettings.color,
        lineWidth: drawingSettings.lineWidth,
      });
    }

    if (draggingHandle) {
      setDraggingHandle(null);
    }
    if (draggingWholeDrawing) {
      setDraggingWholeDrawing(null);
    }
  };

  // Right Click Menu on Canvas (TradingView Context Menu)
  const handleContextMenu = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!candleSeriesRef.current || !chartContainerRef.current) return;
    const rect = chartContainerRef.current.getBoundingClientRect();
    const y = e.clientY - rect.top;
    const price = candleSeriesRef.current.coordinateToPrice(y);
    if (price !== null) {
      setShowRightClickMenu({
        x: Math.min(window.innerWidth - 220, e.clientX),
        y: Math.min(window.innerHeight - 120, e.clientY),
        price,
      });
    }
  };

  // Format price helper
  const formatPriceDisplay = (p: number): string => {
    if (p >= 1000) return p.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    if (p >= 1) return p.toFixed(3);
    if (p >= 0.01) return p.toFixed(4);
    return p.toFixed(6);
  };

  const timeframes = [
    { label: '1m', val: '1m' },
    { label: '3m', val: '3m' },
    { label: '5m', val: '5m' },
    { label: '15m', val: '15m' },
    { label: '30m', val: '30m' },
    { label: '1h', val: '1h' },
    { label: '4h', val: '4h' },
    { label: '1D', val: '1d' },
    { label: '1W', val: '1w' },
  ];

  const isCurrentIntervalCustom = !timeframes.some((t) => t.val === interval);
  const selectedDrawing = drawings.find((d) => d.id === selectedDrawingId);

  return (
    <div className="relative flex-1 h-full bg-[#131722] flex flex-col overflow-hidden select-none">
      {/* Top Chart Header Toolbar */}
      <header className="h-10 bg-[#1E222D] border-b border-[#2B2F3A] flex items-center justify-between px-3 gap-2 shrink-0 z-20">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          <div className="flex items-center gap-1.5 font-bold text-sm text-white shrink-0 tracking-tight">
            <span>{symbol}</span>
            <span className="text-[10px] font-mono font-medium px-1.5 py-0.5 rounded bg-[#2A2E39] text-[#2962FF] uppercase">
              USDT.P
            </span>
          </div>

          <div className="w-px h-4 bg-[#2B2F3A] mx-1 shrink-0" />

          {/* 3-WAY PRICE SOURCE SWITCHER */}
          <div className="flex items-center p-0.5 bg-[#131722] rounded-md border border-[#2B2F3A] shrink-0">
            <button
              onClick={() => onChangePriceType('last')}
              className={`px-2.5 py-1 text-[11px] font-semibold rounded transition-colors whitespace-nowrap cursor-pointer ${
                priceType === 'last' ? 'bg-[#2962FF] text-white shadow-xs' : 'text-[#787B86] hover:text-[#D1D4DC]'
              }`}
            >
              Last Price
            </button>
            <button
              onClick={() => onChangePriceType('mark')}
              className={`px-2.5 py-1 text-[11px] font-semibold rounded transition-colors whitespace-nowrap cursor-pointer ${
                priceType === 'mark' ? 'bg-[#2962FF] text-white shadow-xs' : 'text-[#787B86] hover:text-[#D1D4DC]'
              }`}
            >
              Mark Price
            </button>
            <button
              onClick={() => onChangePriceType('index')}
              className={`px-2.5 py-1 text-[11px] font-semibold rounded transition-colors whitespace-nowrap cursor-pointer ${
                priceType === 'index' ? 'bg-[#2962FF] text-white shadow-xs' : 'text-[#787B86] hover:text-[#D1D4DC]'
              }`}
            >
              Index Price
            </button>
          </div>

          <div className="w-px h-4 bg-[#2B2F3A] mx-1 shrink-0" />

          {/* Timeframes */}
          <div className="flex items-center gap-0.5 shrink-0">
            {timeframes.map((tf) => (
              <button
                key={tf.val}
                onClick={() => onChangeInterval(tf.val)}
                className={`px-1.5 py-1 text-xs font-mono font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                  interval === tf.val
                    ? 'bg-[#2A2E39] text-[#2962FF] font-bold'
                    : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39]/60'
                }`}
              >
                {tf.label}
              </button>
            ))}

            <button
              onClick={onOpenCustomTimeframe}
              className={`px-2 py-1 text-xs font-mono font-medium rounded border transition-colors flex items-center gap-1 cursor-pointer ${
                isCurrentIntervalCustom
                  ? 'border-[#2962FF] bg-[#2962FF]/20 text-white font-bold'
                  : 'border-[#2B2F3A] text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39]'
              }`}
            >
              <Clock className="w-3 h-3" />
              <span>{isCurrentIntervalCustom ? interval : '+'}</span>
            </button>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* TRADINGVIEW BAR REPLAY TRIGGER */}
          <button
            onClick={onToggleReplay}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold border transition-colors cursor-pointer ${
              replayState.isActive
                ? 'bg-[#2962FF] border-[#2962FF] text-white shadow-xs'
                : 'bg-[#131722] border-[#2B2F3A] text-[#D1D4DC] hover:border-[#2962FF]'
            }`}
            title="TradingView Bar Replay"
          >
            <Rewind className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">
              {replayState.isActive ? 'Replay' : 'Replay'}
            </span>
          </button>

          {/* Alert button */}
          <button
            onClick={() => onOpenAlertModal(activeCandleRef.current?.close)}
            className="flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium bg-[#131722] border border-[#2B2F3A] text-[#D1D4DC] hover:border-[#2962FF] transition-colors cursor-pointer"
          >
            <Bell className="w-3.5 h-3.5 text-[#2962FF]" />
            <span className="hidden sm:inline">Alert</span>
            {alerts.filter((a) => a.symbol === symbol && a.status === 'active').length > 0 && (
              <span className="ml-0.5 px-1 bg-[#2962FF] text-white text-[10px] rounded-full font-mono">
                {alerts.filter((a) => a.symbol === symbol && a.status === 'active').length}
              </span>
            )}
          </button>

          {/* Snapshot PNG */}
          <button
            onClick={() => {
              if (!chartRef.current || !chartContainerRef.current) return;
              const canvas = chartContainerRef.current.querySelector('canvas');
              if (canvas) {
                const a = document.createElement('a');
                a.href = canvas.toDataURL('image/png');
                a.download = `${symbol}_${interval}_${Date.now()}.png`;
                a.click();
              }
            }}
            className="p-1.5 rounded text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39] transition-colors cursor-pointer"
            title="Save PNG Snapshot"
          >
            <Camera className="w-4 h-4" />
          </button>

          {/* Fullscreen */}
          <button
            onClick={() => {
              if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
                setIsFullscreen(true);
              } else {
                document.exitFullscreen().catch(() => {});
                setIsFullscreen(false);
              }
            }}
            className="p-1.5 rounded text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39] transition-colors cursor-pointer"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Crosshair & OHLC HUD Overlay */}
      <div className="absolute top-12 left-4 z-10 pointer-events-none flex flex-wrap items-center gap-x-3 gap-y-1 text-xs font-mono">
        <div className="flex items-center gap-1.5 text-[#D1D4DC]">
          <span className="font-bold">{symbol}</span>
          <span className="text-[#787B86]">{interval}</span>
          <span className="text-[10px] text-[#2962FF] uppercase font-bold px-1 rounded bg-[#1E222D]">
            {priceType}
          </span>
        </div>

        {ohlcHud && (
          <div className="flex items-center gap-2.5 text-[11px] tabular-nums">
            <span className="text-[#787B86]">
              O <span className="text-[#D1D4DC]">{formatPriceDisplay(ohlcHud.open)}</span>
            </span>
            <span className="text-[#787B86]">
              H <span className="text-[#D1D4DC]">{formatPriceDisplay(ohlcHud.high)}</span>
            </span>
            <span className="text-[#787B86]">
              L <span className="text-[#D1D4DC]">{formatPriceDisplay(ohlcHud.low)}</span>
            </span>
            <span className="text-[#787B86]">
              C{' '}
              <span className={ohlcHud.close >= ohlcHud.open ? 'text-[#089981]' : 'text-[#F23645]'}>
                {formatPriceDisplay(ohlcHud.close)}
              </span>
            </span>
            <span className={`font-semibold ${ohlcHud.change >= 0 ? 'text-[#089981]' : 'text-[#F23645]'}`}>
              {ohlcHud.change >= 0 ? '+' : ''}
              {ohlcHud.change.toFixed(2)} ({ohlcHud.changePercent >= 0 ? '+' : ''}
              {ohlcHud.changePercent.toFixed(2)}%)
            </span>
            {ohlcHud.volume > 0 && (
              <span className="text-[#787B86] hidden sm:inline">
                Vol <span className="text-[#D1D4DC]">{Math.round(ohlcHud.volume).toLocaleString()}</span>
              </span>
            )}
          </div>
        )}
      </div>

      {/* Loading state indicator */}
      {isLoading && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-[#131722]/80 backdrop-blur-xs">
          <div className="flex flex-col items-center gap-2 text-xs font-mono text-[#787B86]">
            <RefreshCw className="w-6 h-6 animate-spin text-[#2962FF]" />
            <span>Loading {symbol} Binance Data...</span>
          </div>
        </div>
      )}

      {/* Main Chart Canvas Container */}
      <div
        ref={chartContainerRef}
        onContextMenu={handleContextMenu}
        className="flex-1 w-full h-full relative cursor-crosshair overflow-hidden touch-none"
      >
        {/* SVG Drawing Layer */}
        <svg
          ref={overlaySvgRef}
          onPointerDown={handleCanvasPointerDown}
          onPointerMove={handleCanvasPointerMove}
          onPointerUp={handleCanvasPointerUp}
          className="absolute inset-0 w-full h-full z-15 pointer-events-auto select-none"
        >
          <defs>
            <marker
              id="arrowhead"
              markerWidth="8"
              markerHeight="6"
              refX="7"
              refY="3"
              orient="auto"
            >
              <polygon points="0 0, 8 3, 0 6" fill={drawingSettings.color} />
            </marker>
          </defs>

          {/* RENDER ALL SAVED DRAWINGS */}
          {drawings.map((drawing) => {
            if (drawing.hidden) return null;

            const isSelected = selectedDrawingId === drawing.id;
            const strokeDash =
              drawing.lineStyle === 'dashed' ? '5 5' : drawing.lineStyle === 'dotted' ? '2 2' : 'none';

            // Lines: Trendline, Ray, Extended Line, Arrow
            if (
              (drawing.tool === 'trendline' ||
                drawing.tool === 'ray' ||
                drawing.tool === 'extended_line' ||
                drawing.tool === 'arrow') &&
              drawing.points.length >= 2
            ) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              let x1 = p1.x;
              let y1 = p1.y;
              let x2 = p2.x;
              let y2 = p2.y;

              const dx = x2 - x1;
              const dy = y2 - y1;

              if (drawing.tool === 'extended_line' || drawing.extendLeft) {
                x1 -= dx * 10;
                y1 -= dy * 10;
              }
              if (drawing.tool === 'extended_line' || drawing.tool === 'ray' || drawing.extendRight) {
                x2 += dx * 10;
                y2 += dy * 10;
              }

              return (
                <g key={drawing.id}>
                  {/* Invisible hit area for easier selection on touch */}
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="transparent"
                    strokeWidth={18}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                      if (!drawing.locked) {
                        setDraggingWholeDrawing({
                          drawingId: drawing.id,
                          startPoint: drawing.points[0],
                          initialPoints: drawing.points,
                        });
                      }
                    }}
                    onContextMenu={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      setDrawingContextMenu({ x: e.clientX, y: e.clientY, drawing });
                    }}
                  />
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                    markerEnd={drawing.tool === 'arrow' ? 'url(#arrowhead)' : undefined}
                  />
                  {isSelected && (
                    <>
                      <circle
                        cx={p1.x}
                        cy={p1.y}
                        r={6}
                        fill="#FFFFFF"
                        stroke="#2962FF"
                        strokeWidth={2}
                        className="pointer-events-auto cursor-grab"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                        }}
                      />
                      <circle
                        cx={p2.x}
                        cy={p2.y}
                        r={6}
                        fill="#FFFFFF"
                        stroke="#2962FF"
                        strokeWidth={2}
                        className="pointer-events-auto cursor-grab"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 });
                        }}
                      />
                    </>
                  )}
                </g>
              );
            }

            // Horizontal Line
            if (drawing.tool === 'horizontal_line' && drawing.points[0]) {
              const coords = getCoordinates(drawing.points[0]);
              if (!coords) return null;
              return (
                <g key={drawing.id}>
                  <line
                    x1={0}
                    y1={coords.y}
                    x2="100%"
                    y2={coords.y}
                    stroke="transparent"
                    strokeWidth={18}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                    }}
                    onContextMenu={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      setDrawingContextMenu({ x: e.clientX, y: e.clientY, drawing });
                    }}
                  />
                  <line
                    x1={drawing.extendLeft ? 0 : coords.x}
                    y1={coords.y}
                    x2="100%"
                    y2={coords.y}
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                  />
                  <text
                    x={10}
                    y={coords.y - 4}
                    fill={drawing.color}
                    fontSize={10}
                    fontFamily="monospace"
                  >
                    Level: {drawing.points[0].price.toFixed(2)}
                  </text>
                  {isSelected && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={6}
                      fill="#FFFFFF"
                      stroke="#2962FF"
                      strokeWidth={2}
                      className="pointer-events-auto cursor-ns-resize"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                      }}
                    />
                  )}
                </g>
              );
            }

            // Horizontal Ray
            if (drawing.tool === 'horizontal_ray' && drawing.points[0]) {
              const coords = getCoordinates(drawing.points[0]);
              if (!coords) return null;
              return (
                <g key={drawing.id}>
                  <line
                    x1={coords.x}
                    y1={coords.y}
                    x2="100%"
                    y2={coords.y}
                    stroke="transparent"
                    strokeWidth={18}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                    }}
                    onContextMenu={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      setDrawingContextMenu({ x: e.clientX, y: e.clientY, drawing });
                    }}
                  />
                  <line
                    x1={coords.x}
                    y1={coords.y}
                    x2="100%"
                    y2={coords.y}
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                  />
                  <circle cx={coords.x} cy={coords.y} r={3} fill={drawing.color} />
                  {isSelected && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={6}
                      fill="#FFFFFF"
                      stroke="#2962FF"
                      strokeWidth={2}
                      className="pointer-events-auto cursor-grab"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                      }}
                    />
                  )}
                </g>
              );
            }

            // Vertical Line
            if (drawing.tool === 'vertical_line' && drawing.points[0]) {
              const coords = getCoordinates(drawing.points[0]);
              if (!coords) return null;
              return (
                <g key={drawing.id}>
                  <line
                    x1={coords.x}
                    y1={0}
                    x2={coords.x}
                    y2="100%"
                    stroke="transparent"
                    strokeWidth={18}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                    }}
                    onContextMenu={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      setDrawingContextMenu({ x: e.clientX, y: e.clientY, drawing });
                    }}
                  />
                  <line
                    x1={coords.x}
                    y1={0}
                    x2={coords.x}
                    y2="100%"
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                  />
                  {isSelected && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={6}
                      fill="#FFFFFF"
                      stroke="#2962FF"
                      strokeWidth={2}
                      className="pointer-events-auto cursor-ew-resize"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                      }}
                    />
                  )}
                </g>
              );
            }

            // Cross Line (Full Horizontal + Vertical intersection)
            if (drawing.tool === 'cross_line' && drawing.points[0]) {
              const coords = getCoordinates(drawing.points[0]);
              if (!coords) return null;
              return (
                <g key={drawing.id}>
                  {/* Horz */}
                  <line x1={0} y1={coords.y} x2="100%" y2={coords.y} stroke={drawing.color} strokeWidth={drawing.lineWidth} strokeDasharray={strokeDash} />
                  {/* Vert */}
                  <line x1={coords.x} y1={0} x2={coords.x} y2="100%" stroke={drawing.color} strokeWidth={drawing.lineWidth} strokeDasharray={strokeDash} />
                  {/* Price Tag */}
                  <rect x={10} y={coords.y - 18} width={80} height={16} rx={3} fill="#1E222D" stroke={drawing.color} strokeWidth={1} />
                  <text x={14} y={coords.y - 6} fill={drawing.color} fontSize={9} fontFamily="monospace">
                    {drawing.points[0].price.toFixed(2)}
                  </text>
                  {isSelected && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={6}
                      fill="#FFFFFF"
                      stroke="#2962FF"
                      strokeWidth={2}
                      className="pointer-events-auto cursor-move"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                      }}
                    />
                  )}
                </g>
              );
            }

            // Rectangle Box
            if (drawing.tool === 'rectangle' && drawing.points.length >= 2) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              const x = Math.min(p1.x, p2.x);
              const y = Math.min(p1.y, p2.y);
              const w = Math.max(2, Math.abs(p2.x - p1.x));
              const h = Math.max(2, Math.abs(p2.y - p1.y));

              return (
                <g key={drawing.id}>
                  <rect
                    x={x}
                    y={y}
                    width={w}
                    height={h}
                    fill={drawing.fillColor || drawing.color}
                    fillOpacity={drawing.fillOpacity || 0.15}
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                      if (!drawing.locked) {
                        setDraggingWholeDrawing({
                          drawingId: drawing.id,
                          startPoint: drawing.points[0],
                          initialPoints: drawing.points,
                        });
                      }
                    }}
                    onContextMenu={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      setDrawingContextMenu({ x: e.clientX, y: e.clientY, drawing });
                    }}
                  />
                  {isSelected && (
                    <>
                      <circle
                        cx={p1.x}
                        cy={p1.y}
                        r={6}
                        fill="#FFFFFF"
                        stroke="#2962FF"
                        strokeWidth={2}
                        className="pointer-events-auto cursor-grab"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                        }}
                      />
                      <circle
                        cx={p2.x}
                        cy={p2.y}
                        r={6}
                        fill="#FFFFFF"
                        stroke="#2962FF"
                        strokeWidth={2}
                        className="pointer-events-auto cursor-grab"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 });
                        }}
                      />
                    </>
                  )}
                </g>
              );
            }

            // Circle
            if (drawing.tool === 'circle' && drawing.points.length >= 2) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              const r = Math.hypot(p2.x - p1.x, p2.y - p1.y);

              return (
                <g key={drawing.id}>
                  <circle
                    cx={p1.x}
                    cy={p1.y}
                    r={r}
                    fill={drawing.fillColor || drawing.color}
                    fillOpacity={drawing.fillOpacity || 0.15}
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                      if (!drawing.locked) {
                        setDraggingWholeDrawing({
                          drawingId: drawing.id,
                          startPoint: drawing.points[0],
                          initialPoints: drawing.points,
                        });
                      }
                    }}
                  />
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                    </>
                  )}
                </g>
              );
            }

            // Ellipse
            if (drawing.tool === 'ellipse' && drawing.points.length >= 2) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              const cx = (p1.x + p2.x) / 2;
              const cy = (p1.y + p2.y) / 2;
              const rx = Math.max(2, Math.abs(p2.x - p1.x) / 2);
              const ry = Math.max(2, Math.abs(p2.y - p1.y) / 2);

              return (
                <g key={drawing.id}>
                  <ellipse
                    cx={cx}
                    cy={cy}
                    rx={rx}
                    ry={ry}
                    fill={drawing.fillColor || drawing.color}
                    fillOpacity={drawing.fillOpacity || 0.15}
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                    }}
                  />
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                    </>
                  )}
                </g>
              );
            }

            // Parallel Channel (3 Points)
            if (drawing.tool === 'parallel_channel' && drawing.points.length >= 3) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              const p3 = getCoordinates(drawing.points[2]);
              if (!p1 || !p2 || !p3) return null;

              // Baseline vector: p1 -> p2
              const offY = p3.y - p1.y;
              const offX = p3.x - p1.x;

              const p4x = p2.x + offX;
              const p4y = p2.y + offY;

              const mid1x = (p1.x + p3.x) / 2;
              const mid1y = (p1.y + p3.y) / 2;
              const mid2x = (p2.x + p4x) / 2;
              const mid2y = (p2.y + p4y) / 2;

              return (
                <g key={drawing.id}>
                  {/* Shaded Channel Polygon */}
                  <polygon
                    points={`${p1.x},${p1.y} ${p2.x},${p2.y} ${p4x},${p4y} ${p3.x},${p3.y}`}
                    fill={drawing.fillColor || drawing.color}
                    fillOpacity={drawing.fillOpacity || 0.12}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                    }}
                  />
                  {/* Baseline 1 */}
                  <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke={drawing.color} strokeWidth={drawing.lineWidth} />
                  {/* Parallel Line 2 */}
                  <line x1={p3.x} y1={p3.y} x2={p4x} y2={p4y} stroke={drawing.color} strokeWidth={drawing.lineWidth} />
                  {/* Midline */}
                  <line x1={mid1x} y1={mid1y} x2={mid2x} y2={mid2y} stroke={drawing.color} strokeWidth={1} strokeDasharray="4 4" />
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                      <circle cx={p3.x} cy={p3.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 2 }); }} />
                    </>
                  )}
                </g>
              );
            }

            // Polyline / Path
            if (drawing.tool === 'polyline' && drawing.points.length > 1) {
              const pts = drawing.points
                .map((p) => getCoordinates(p))
                .filter((p): p is { x: number; y: number } => p !== null);

              if (pts.length < 2) return null;
              const pathD = `M ${pts[0].x} ${pts[0].y} ` + pts.slice(1).map((p) => `L ${p.x} ${p.y}`).join(' ');

              return (
                <g key={drawing.id}>
                  <path
                    d={pathD}
                    fill="none"
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeDasharray={strokeDash}
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                    }}
                  />
                  {isSelected &&
                    pts.map((pt, i) => (
                      <circle
                        key={i}
                        cx={pt.x}
                        cy={pt.y}
                        r={5}
                        fill="#FFFFFF"
                        stroke="#2962FF"
                        strokeWidth={2}
                        className="cursor-grab"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: i });
                        }}
                      />
                    ))}
                </g>
              );
            }

            // Freehand Brush
            if (drawing.tool === 'brush' && drawing.brushPoints && drawing.brushPoints.length > 1) {
              const pts = drawing.brushPoints
                .map((p) => getCoordinates(p))
                .filter((p): p is { x: number; y: number } => p !== null);

              if (pts.length < 2) return null;
              const pathD = `M ${pts[0].x} ${pts[0].y} ` + pts.slice(1).map((p) => `L ${p.x} ${p.y}`).join(' ');

              return (
                <g key={drawing.id}>
                  <path
                    d={pathD}
                    fill="none"
                    stroke={drawing.color}
                    strokeWidth={drawing.lineWidth}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="pointer-events-auto cursor-pointer"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      setSelectedDrawingId(drawing.id);
                    }}
                  />
                </g>
              );
            }

            // Text Note Annotation
            if (drawing.tool === 'text' && drawing.points[0]) {
              const coords = getCoordinates(drawing.points[0]);
              if (!coords) return null;

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                  onDoubleClick={(e) => {
                    e.stopPropagation();
                    const newTxt = window.prompt('Edit Note Text:', drawing.text || '') || drawing.text;
                    onUpdateDrawing({ ...drawing, text: newTxt });
                  }}
                >
                  <rect
                    x={coords.x - 4}
                    y={coords.y - (drawing.fontSize || 14) - 2}
                    width={((drawing.text?.length || 4) * (drawing.fontSize || 14) * 0.6) + 12}
                    height={(drawing.fontSize || 14) + 8}
                    rx={4}
                    fill="#1E222D"
                    fillOpacity={0.8}
                    stroke={isSelected ? '#2962FF' : '#2B2F3A'}
                    strokeWidth={1}
                  />
                  <text
                    x={coords.x + 2}
                    y={coords.y - 2}
                    fill={drawing.color}
                    fontSize={drawing.fontSize || 14}
                    fontWeight="500"
                    fontFamily="'JetBrains Mono', monospace"
                  >
                    {drawing.text || 'Note'}
                  </text>
                  {isSelected && (
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={5}
                      fill="#FFFFFF"
                      stroke="#2962FF"
                      strokeWidth={2}
                      className="cursor-move"
                      onPointerDown={(e) => {
                        e.stopPropagation();
                        if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                      }}
                    />
                  )}
                </g>
              );
            }

            // Price Label Badge
            if (drawing.tool === 'price_label' && drawing.points[0]) {
              const coords = getCoordinates(drawing.points[0]);
              if (!coords) return null;
              const priceText = drawing.points[0].price.toFixed(2);
              const tagW = 75;
              const tagH = 20;

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                >
                  <polygon
                    points={`${coords.x},${coords.y} ${coords.x + 8},${coords.y - 10} ${coords.x + tagW},${coords.y - 10} ${coords.x + tagW},${coords.y + 10} ${coords.x + 8},${coords.y + 10}`}
                    fill="#1E222D"
                    stroke={drawing.color}
                    strokeWidth={1.5}
                  />
                  <text
                    x={coords.x + 16}
                    y={coords.y + 3.5}
                    fill="#FFFFFF"
                    fontSize={10}
                    fontWeight="bold"
                    fontFamily="monospace"
                  >
                    {priceText}
                  </text>
                  {isSelected && (
                    <circle cx={coords.x} cy={coords.y} r={5} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} />
                  )}
                </g>
              );
            }

            // Arrow Marker (Buy/Sell signal)
            if (drawing.tool === 'arrow_marker' && drawing.points[0]) {
              const coords = getCoordinates(drawing.points[0]);
              if (!coords) return null;

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                >
                  <circle cx={coords.x} cy={coords.y} r={14} fill={drawing.color} fillOpacity={0.2} stroke={drawing.color} strokeWidth={1.5} />
                  <polygon points={`${coords.x},${coords.y - 7} ${coords.x - 6},${coords.y + 5} ${coords.x + 6},${coords.y + 5}`} fill={drawing.color} />
                  {isSelected && (
                    <circle cx={coords.x} cy={coords.y} r={5} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} />
                  )}
                </g>
              );
            }

            // Fibonacci Retracement
            if (drawing.tool === 'fibonacci' && drawing.points.length >= 2) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              const highPrice = Math.max(drawing.points[0].price, drawing.points[1].price);
              const lowPrice = Math.min(drawing.points[0].price, drawing.points[1].price);
              const diff = highPrice - lowPrice;

              const fibLevels = [
                { ratio: 0.0, color: '#787B86' },
                { ratio: 0.236, color: '#F23645' },
                { ratio: 0.382, color: '#F59E0B' },
                { ratio: 0.5, color: '#089981' },
                { ratio: 0.618, color: '#2962FF' },
                { ratio: 0.786, color: '#A855F7' },
                { ratio: 1.0, color: '#787B86' },
              ];

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                >
                  <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#787B86" strokeWidth={1} strokeDasharray="3 3" />
                  {fibLevels.map((lvl) => {
                    const priceAtLvl = highPrice - diff * lvl.ratio;
                    const y = candleSeriesRef.current?.priceToCoordinate(priceAtLvl);
                    if (y === null || y === undefined) return null;

                    return (
                      <g key={lvl.ratio}>
                        <line x1={Math.min(p1.x, p2.x)} y1={y} x2="100%" y2={y} stroke={lvl.color} strokeWidth={1} strokeDasharray={lvl.ratio === 0.5 ? 'none' : '3 3'} />
                        <text x={Math.min(p1.x, p2.x) + 5} y={y - 3} fill={lvl.color} fontSize={9} fontFamily="monospace">
                          {lvl.ratio} ({priceAtLvl.toFixed(2)})
                        </text>
                      </g>
                    );
                  })}
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                    </>
                  )}
                </g>
              );
            }

            // Fibonacci Extension (3 Points: 0.618, 1.0, 1.618, 2.618)
            if (drawing.tool === 'fibonacci_extension' && drawing.points.length >= 3) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              const p3 = getCoordinates(drawing.points[2]);
              if (!p1 || !p2 || !p3) return null;

              const waveHeight = drawing.points[1].price - drawing.points[0].price;
              const extLevels = [
                { ratio: 0.618, label: '0.618 Ext' },
                { ratio: 1.0, label: '1.0 Ext' },
                { ratio: 1.618, label: '1.618 Ext' },
                { ratio: 2.618, label: '2.618 Ext' },
              ];

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                >
                  <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="#2962FF" strokeWidth={1.5} />
                  <line x1={p2.x} y1={p2.y} x2={p3.x} y2={p3.y} stroke="#2962FF" strokeWidth={1} strokeDasharray="3 3" />
                  {extLevels.map((lvl) => {
                    const extPrice = drawing.points[2].price + waveHeight * lvl.ratio;
                    const y = candleSeriesRef.current?.priceToCoordinate(extPrice);
                    if (y === null || y === undefined) return null;

                    return (
                      <g key={lvl.label}>
                        <line x1={p3.x} y1={y} x2="100%" y2={y} stroke="#A855F7" strokeWidth={1} strokeDasharray="3 3" />
                        <text x={p3.x + 5} y={y - 3} fill="#A855F7" fontSize={9} fontFamily="monospace">
                          {lvl.label} ({extPrice.toFixed(2)})
                        </text>
                      </g>
                    );
                  })}
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                      <circle cx={p3.x} cy={p3.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 2 }); }} />
                    </>
                  )}
                </g>
              );
            }

            // Fibonacci Channel (3 Points)
            if (drawing.tool === 'fibonacci_channel' && drawing.points.length >= 3) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              const p3 = getCoordinates(drawing.points[2]);
              if (!p1 || !p2 || !p3) return null;

              const dy = p3.y - p1.y;
              const dx = p3.x - p1.x;

              const ratios = [0.618, 1.0, 1.618, 2.618];

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                >
                  <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke={drawing.color} strokeWidth={1.5} />
                  {ratios.map((r) => (
                    <line
                      key={r}
                      x1={p1.x + dx * r}
                      y1={p1.y + dy * r}
                      x2={p2.x + dx * r}
                      y2={p2.y + dy * r}
                      stroke={drawing.color}
                      strokeWidth={1}
                      strokeDasharray="4 4"
                    />
                  ))}
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                      <circle cx={p3.x} cy={p3.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 2 }); }} />
                    </>
                  )}
                </g>
              );
            }

            // Fibonacci Time Zones (2 Points define unit interval)
            if (drawing.tool === 'fibonacci_timezones' && drawing.points.length >= 2) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              const baseDx = Math.abs(p2.x - p1.x);
              const startX = Math.min(p1.x, p2.x);
              const fibSeq = [1, 2, 3, 5, 8, 13, 21];

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                >
                  <line x1={startX} y1={0} x2={startX} y2="100%" stroke="#089981" strokeWidth={1.5} />
                  {fibSeq.map((f) => {
                    const x = startX + baseDx * f;
                    return (
                      <g key={f}>
                        <line x1={x} y1={0} x2={x} y2="100%" stroke="#2962FF" strokeWidth={1} strokeDasharray="4 4" />
                        <text x={x + 4} y={35} fill="#2962FF" fontSize={9} fontFamily="monospace">
                          {f}
                        </text>
                      </g>
                    );
                  })}
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                    </>
                  )}
                </g>
              );
            }

            // Price Percentage Measure Tool (% Change, Absolute Delta, Candle Count, Direction)
            if (drawing.tool === 'price_percentage_measure' && drawing.points.length >= 2) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              const startPrice = drawing.points[0].price;
              const endPrice = drawing.points[1].price;
              const deltaPrice = endPrice - startPrice;
              const pctChange = startPrice !== 0 ? ((endPrice - startPrice) / startPrice) * 100 : 0;
              const isBullish = deltaPrice >= 0;
              const themeColor = isBullish ? '#089981' : '#F23645';
              const direction = isBullish ? 'UP' : 'DOWN';
              const arrowSym = isBullish ? '▲' : '▼';
              const sign = isBullish ? '+' : '';

              const xMin = Math.min(p1.x, p2.x);
              const yMin = Math.min(p1.y, p2.y);
              const w = Math.max(2, Math.abs(p2.x - p1.x));
              const h = Math.max(2, Math.abs(p2.y - p1.y));

              // Compute candle count
              let barCount = 1;
              const tMin = Math.min(drawing.points[0].time, drawing.points[1].time);
              const tMax = Math.max(drawing.points[0].time, drawing.points[1].time);
              if (fullCandlesRef.current.length > 0) {
                const idx1 = fullCandlesRef.current.findIndex((c) => c.time >= tMin);
                const idx2 = fullCandlesRef.current.findIndex((c) => c.time >= tMax);
                if (idx1 !== -1 && idx2 !== -1) {
                  barCount = Math.max(1, Math.abs(idx2 - idx1));
                }
              }
              const timeDiffSec = Math.abs(drawing.points[1].time - drawing.points[0].time);
              const hours = Math.floor(timeDiffSec / 3600);
              const minutes = Math.floor((timeDiffSec % 3600) / 60);
              const durationStr = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;

              // Card anchor position
              const cardW = 210;
              const cardH = 58;
              let cardX = p2.x - cardW / 2;
              let cardY = isBullish ? p2.y - cardH - 12 : p2.y + 12;
              if (cardX < 10) cardX = 10;
              if (cardY < 40) cardY = 40;

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                    if (!drawing.locked) {
                      setDraggingWholeDrawing({
                        drawingId: drawing.id,
                        startPoint: drawing.points[0],
                        initialPoints: drawing.points,
                      });
                    }
                  }}
                  onContextMenu={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    setDrawingContextMenu({ x: e.clientX, y: e.clientY, drawing });
                  }}
                >
                  {/* Shaded Measurement Zone */}
                  <rect
                    x={xMin}
                    y={yMin}
                    width={w}
                    height={h}
                    fill={themeColor}
                    fillOpacity={0.12}
                    stroke={themeColor}
                    strokeWidth={1.5}
                    strokeDasharray="4 4"
                  />

                  {/* Trend line */}
                  <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke={themeColor} strokeWidth={2} />

                  {/* HUD Badge */}
                  <g transform={`translate(${cardX}, ${cardY})`}>
                    <rect
                      x={0}
                      y={0}
                      width={cardW}
                      height={cardH}
                      rx={6}
                      fill="#181B24"
                      fillOpacity={0.92}
                      stroke={themeColor}
                      strokeWidth={1.5}
                    />
                    <text x={10} y={18} fill={themeColor} fontSize={12} fontWeight="bold" fontFamily="monospace">
                      {arrowSym} {sign}{pctChange.toFixed(2)}% ({sign}{deltaPrice.toFixed(2)})
                    </text>
                    <text x={cardW - 10} y={18} fill={themeColor} fontSize={10} fontWeight="bold" fontFamily="sans-serif" textAnchor="end">
                      {direction}
                    </text>
                    <text x={10} y={34} fill="#D1D4DC" fontSize={10} fontFamily="monospace">
                      {startPrice.toFixed(2)} → {endPrice.toFixed(2)}
                    </text>
                    <text x={10} y={48} fill="#787B86" fontSize={9} fontFamily="monospace">
                      {barCount} {barCount === 1 ? 'candle' : 'candles'} | {durationStr}
                    </text>
                  </g>

                  {/* Resizing Point Handles */}
                  {isSelected && (
                    <>
                      <circle
                        cx={p1.x}
                        cy={p1.y}
                        r={6}
                        fill="#FFFFFF"
                        stroke={themeColor}
                        strokeWidth={2}
                        className="cursor-grab"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 });
                        }}
                      />
                      <circle
                        cx={p2.x}
                        cy={p2.y}
                        r={6}
                        fill="#FFFFFF"
                        stroke={themeColor}
                        strokeWidth={2}
                        className="cursor-grab"
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 });
                        }}
                      />
                    </>
                  )}
                </g>
              );
            }

            // Price Range & Date/Price Range & Date Range
            if (
              (drawing.tool === 'price_range' ||
                drawing.tool === 'date_and_price_range' ||
                drawing.tool === 'date_range') &&
              drawing.points.length >= 2
            ) {
              const p1 = getCoordinates(drawing.points[0]);
              const p2 = getCoordinates(drawing.points[1]);
              if (!p1 || !p2) return null;

              const priceChange = drawing.points[1].price - drawing.points[0].price;
              const pricePercent = (priceChange / drawing.points[0].price) * 100;
              const isGain = priceChange >= 0;
              const x = Math.min(p1.x, p2.x);
              const y = Math.min(p1.y, p2.y);
              const w = Math.max(2, Math.abs(p2.x - p1.x));
              const h = Math.max(2, Math.abs(p2.y - p1.y));

              const timeDiffSec = Math.abs(drawing.points[1].time - drawing.points[0].time);
              const minutesPerBar = parseIntervalToMinutes(interval);
              const barCount = Math.max(1, Math.round(timeDiffSec / (minutesPerBar * 60)));

              return (
                <g
                  key={drawing.id}
                  className="pointer-events-auto cursor-pointer"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setSelectedDrawingId(drawing.id);
                  }}
                >
                  <rect
                    x={x}
                    y={y}
                    width={w}
                    height={h}
                    fill={isGain ? '#089981' : '#F23645'}
                    fillOpacity={0.15}
                    stroke={isGain ? '#089981' : '#F23645'}
                    strokeWidth={1.5}
                    strokeDasharray="3 3"
                  />
                  {drawing.tool !== 'date_range' && (
                    <text
                      x={x + w / 2}
                      y={y + h / 2 - (drawing.tool === 'date_and_price_range' ? 6 : 0)}
                      fill={isGain ? '#089981' : '#F23645'}
                      fontSize={11}
                      fontFamily="monospace"
                      textAnchor="middle"
                      fontWeight="bold"
                    >
                      {isGain ? '+' : ''}
                      {priceChange.toFixed(2)} ({isGain ? '+' : ''}
                      {pricePercent.toFixed(2)}%)
                    </text>
                  )}
                  {(drawing.tool === 'date_and_price_range' || drawing.tool === 'date_range') && (
                    <text
                      x={x + w / 2}
                      y={y + h / 2 + 10}
                      fill="#D1D4DC"
                      fontSize={10}
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {barCount} bars, {Math.round(timeDiffSec / 3600)}h
                    </text>
                  )}
                  {isSelected && (
                    <>
                      <circle cx={p1.x} cy={p1.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 0 }); }} />
                      <circle cx={p2.x} cy={p2.y} r={6} fill="#FFFFFF" stroke="#2962FF" strokeWidth={2} className="cursor-grab" onPointerDown={(e) => { e.stopPropagation(); if (!drawing.locked) setDraggingHandle({ drawingId: drawing.id, pointIndex: 1 }); }} />
                    </>
                  )}
                </g>
              );
            }

            return null;
          })}

          {/* ACTIVE 2-POINT / 3-POINT LIVE CREATION PREVIEW (FIXED: NEVER renders ghost diagonal lines) */}
          {creationPoints.length > 0 &&
            activeDrawingTool !== 'cursor' &&
            currentMouseCoord &&
            (() => {
              const startCoords = getCoordinates(creationPoints[0]);
              if (!startCoords) return null;

              return (
                <line
                  x1={startCoords.x}
                  y1={startCoords.y}
                  x2={currentMouseCoord.x}
                  y2={currentMouseCoord.y}
                  stroke={drawingSettings.color}
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                />
              );
            })()}

          {/* Active Freehand Brush drawing in progress */}
          {isBrushDrawing && activeBrushPoints.length > 1 && (
            <path
              d={
                `M ${getCoordinates(activeBrushPoints[0])?.x || 0} ${getCoordinates(activeBrushPoints[0])?.y || 0} ` +
                activeBrushPoints
                  .slice(1)
                  .map((p) => {
                    const c = getCoordinates(p);
                    return c ? `L ${c.x} ${c.y}` : '';
                  })
                  .join(' ')
              }
              fill="none"
              stroke={drawingSettings.color}
              strokeWidth={drawingSettings.lineWidth}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* VERTICAL REPLAY STARTING CUTOFF MARKER */}
          {replayState.isActive && replayState.cutoffTime && (() => {
            const coord = getCoordinates({
              time: replayState.cutoffTime,
              price: activeCandleRef.current?.close || 0,
            });
            if (!coord) return null;
            return (
              <g className="pointer-events-none">
                <line
                  x1={coord.x}
                  y1={0}
                  x2={coord.x}
                  y2="100%"
                  stroke="#2962FF"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                />
                <rect
                  x={coord.x - 44}
                  y={46}
                  width={88}
                  height={22}
                  rx={4}
                  fill="#2962FF"
                  fillOpacity={0.9}
                />
                <text
                  x={coord.x}
                  y={61}
                  fill="#FFFFFF"
                  fontSize={10}
                  fontWeight="bold"
                  fontFamily="sans-serif"
                  textAnchor="middle"
                >
                  Replay Start
                </text>
              </g>
            );
          })()}
        </svg>

        {/* FLOATING ACTION TOOLBAR FOR SELECTED DRAWING */}
        {selectedDrawing && (
          <div
            style={{
              top: '56px',
              left: '50%',
              transform: 'translateX(-50%)',
            }}
            className="absolute z-35 flex items-center gap-1.5 p-1.5 bg-[#1E222D]/95 border border-[#2B2F3A] rounded-lg shadow-2xl backdrop-blur-md select-none text-xs"
          >
            <span className="text-[10px] uppercase font-semibold text-[#787B86] px-1">
              {selectedDrawing.tool.replace(/_/g, ' ')}
            </span>

            {/* Color options */}
            <div className="flex items-center gap-1">
              {['#2962FF', '#089981', '#F23645', '#F59E0B', '#A855F7', '#FFFFFF'].map((col) => (
                <button
                  key={col}
                  onClick={() => onUpdateDrawing({ ...selectedDrawing, color: col })}
                  style={{ backgroundColor: col }}
                  className={`w-4 h-4 rounded-full border transition-transform ${
                    selectedDrawing.color === col ? 'border-white scale-110' : 'border-transparent'
                  }`}
                />
              ))}
            </div>

            <div className="w-px h-4 bg-[#2B2F3A] mx-0.5" />

            {/* Line Width */}
            <div className="flex items-center gap-0.5">
              {[1, 2, 3, 4].map((w) => (
                <button
                  key={w}
                  onClick={() => onUpdateDrawing({ ...selectedDrawing, lineWidth: w })}
                  className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
                    selectedDrawing.lineWidth === w
                      ? 'bg-[#2962FF] text-white font-bold'
                      : 'text-[#787B86] hover:text-[#D1D4DC]'
                  }`}
                >
                  {w}px
                </button>
              ))}
            </div>

            <div className="w-px h-4 bg-[#2B2F3A] mx-0.5" />

            {/* Lock / Unlock */}
            <button
              onClick={() => onUpdateDrawing({ ...selectedDrawing, locked: !selectedDrawing.locked })}
              title={selectedDrawing.locked ? 'Unlock Drawing' : 'Lock Drawing'}
              className="p-1 rounded text-[#787B86] hover:text-white hover:bg-[#2A2E39]"
            >
              {selectedDrawing.locked ? <Lock className="w-3.5 h-3.5 text-[#F59E0B]" /> : <Unlock className="w-3.5 h-3.5" />}
            </button>

            {/* Duplicate */}
            <button
              onClick={() => {
                const dup: DrawingItem = {
                  ...selectedDrawing,
                  id: 'drawing_' + Date.now(),
                  points: selectedDrawing.points.map((p) => ({
                    time: p.time + 60,
                    price: p.price * 1.002,
                  })),
                };
                onAddDrawing(dup);
                setSelectedDrawingId(dup.id);
              }}
              title="Duplicate Drawing"
              className="p-1 rounded text-[#787B86] hover:text-white hover:bg-[#2A2E39]"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>

            {/* Delete button */}
            <button
              onClick={() => {
                onDeleteDrawing(selectedDrawing.id);
                setSelectedDrawingId(null);
              }}
              className="p-1 rounded text-[#787B86] hover:text-[#F23645] hover:bg-[#2A2E39]"
              title="Delete Drawing (Del/Backspace)"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>

            {/* Deselect / Check */}
            <button
              onClick={() => setSelectedDrawingId(null)}
              className="p-1 rounded text-[#787B86] hover:text-white hover:bg-[#2A2E39]"
              title="Done"
            >
              <Check className="w-3.5 h-3.5 text-[#089981]" />
            </button>
          </div>
        )}

        {/* DRAGGABLE PRICE ALERTS (Interactive scale badges) */}
        {alerts
          .filter((a) => a.symbol === symbol && a.status === 'active')
          .map((alert) => {
            const yCoord = candleSeriesRef.current?.priceToCoordinate(
              draggingAlert?.id === alert.id ? draggingAlert.currentPrice : alert.price
            );
            if (yCoord === null || yCoord === undefined) return null;

            return (
              <div
                key={alert.id}
                style={{ top: `${yCoord - 10}px` }}
                onMouseDown={(e) => handleAlertMouseDown(alert.id, alert.price, e)}
                className="absolute right-0 z-30 flex items-center gap-1 bg-[#F23645] text-white px-2 py-0.5 rounded-l text-[10px] font-mono font-bold shadow-md cursor-ns-resize hover:bg-[#d62534] transition-colors select-none"
                title="Drag to adjust price alert level"
              >
                <Bell className="w-2.5 h-2.5 fill-current" />
                <span>{(draggingAlert?.id === alert.id ? draggingAlert.currentPrice : alert.price).toFixed(2)}</span>
              </div>
            );
          })}

        {/* Live Candle Countdown Timer Badge adjacent to active price line */}
        {activePriceY !== null && activePriceY > 0 && (
          <div
            style={{ top: `${activePriceY + 12}px` }}
            className="absolute right-0 z-20 bg-[#1E222D] text-[#787B86] px-1.5 py-0.5 rounded-l text-[9px] font-mono border border-r-0 border-[#2B2F3A] pointer-events-none select-none flex items-center gap-1 shadow-sm"
          >
            <Clock className="w-2.5 h-2.5 text-[#2962FF]" />
            <span>{countdownText}</span>
          </div>
        )}
      </div>

      {/* Bottom Chart Footer Controls */}
      <div className="h-7 bg-[#1E222D] border-t border-[#2B2F3A] flex items-center justify-between px-3 text-[11px] text-[#787B86] shrink-0 z-20">
        <div className="flex items-center gap-2 font-mono text-[10px]">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#089981]" />
            <span>Binance Futures WebSocket</span>
          </span>
          <span className="text-[#2B2F3A]">|</span>
          <span>Drawings: {drawings.length}</span>
          {magnetMode && (
            <>
              <span className="text-[#2B2F3A]">|</span>
              <span className="text-[#2962FF] font-bold">Magnet Active</span>
            </>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              if (!chartRef.current) return;
              const nextAuto = !isAutoScale;
              setIsAutoScale(nextAuto);
              chartRef.current.priceScale('right').applyOptions({ autoScale: nextAuto });
            }}
            className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors ${
              isAutoScale ? 'bg-[#2962FF] text-white' : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39]'
            }`}
          >
            auto
          </button>
          <button
            onClick={() => {
              if (!chartRef.current) return;
              const nextLog = !isLogScale;
              setIsLogScale(nextLog);
              chartRef.current.priceScale('right').applyOptions({
                mode: nextLog ? PriceScaleMode.Logarithmic : PriceScaleMode.Normal,
              });
            }}
            className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors ${
              isLogScale ? 'bg-[#2962FF] text-white' : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39]'
            }`}
          >
            log
          </button>
          <button
            onClick={() => {
              if (!chartRef.current) return;
              chartRef.current.timeScale().resetTimeScale();
              chartRef.current.priceScale('right').applyOptions({ autoScale: true });
              setIsAutoScale(true);
            }}
            className="px-1.5 py-0.5 text-[10px] text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#2A2E39] rounded transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Right Click Context Menu (SMART AUTO-CLOSING, NO "Close Menu" item) */}
      {showRightClickMenu && (
        <div
          ref={contextMenuRef}
          style={{ top: showRightClickMenu.y, left: showRightClickMenu.x }}
          className="fixed z-50 bg-[#1E222D] border border-[#2B2F3A] rounded-lg shadow-2xl py-1 text-xs text-[#D1D4DC] min-w-44 select-none backdrop-blur-md"
        >
          <button
            onClick={() => {
              onOpenAlertModal(showRightClickMenu.price);
              setShowRightClickMenu(null);
            }}
            className="w-full text-left px-3 py-2 hover:bg-[#2A2E39] flex items-center gap-2 cursor-pointer transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5 text-[#2962FF]" />
            <span>Add Alert at {showRightClickMenu.price.toFixed(2)}</span>
          </button>
          <button
            onClick={() => {
              onAddDrawing({
                id: 'drawing_' + Date.now(),
                tool: 'horizontal_line',
                points: [{ time: Math.floor(Date.now() / 1000), price: showRightClickMenu.price }],
                color: drawingSettings.color,
                lineWidth: drawingSettings.lineWidth,
                extendLeft: drawingSettings.extendLeft,
                extendRight: drawingSettings.extendRight,
              });
              setShowRightClickMenu(null);
            }}
            className="w-full text-left px-3 py-2 hover:bg-[#2A2E39] flex items-center gap-2 cursor-pointer transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#089981]" />
            <span>Draw Horizontal Level</span>
          </button>
        </div>
      )}

      {/* Dedicated Context Menu for Right-Click on an existing Drawing */}
      {drawingContextMenu && (
        <div
          ref={drawingContextMenuRef}
          style={{ top: drawingContextMenu.y, left: drawingContextMenu.x }}
          className="fixed z-50 bg-[#1E222D] border border-[#2B2F3A] rounded-lg shadow-2xl py-1 text-xs text-[#D1D4DC] min-w-48 select-none backdrop-blur-md"
        >
          <div className="px-3 py-1 text-[10px] uppercase font-bold text-[#787B86] border-b border-[#2B2F3A]">
            {drawingContextMenu.drawing.tool.replace(/_/g, ' ')}
          </div>
          <button
            onClick={() => {
              setSelectedDrawingId(drawingContextMenu.drawing.id);
              onOpenSettingsModal?.();
              setDrawingContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2A2E39] flex items-center gap-2 cursor-pointer"
          >
            <Pencil className="w-3.5 h-3.5 text-[#2962FF]" />
            <span>Settings / Properties</span>
          </button>
          <button
            onClick={() => {
              const dup: DrawingItem = {
                ...drawingContextMenu.drawing,
                id: 'drawing_' + Date.now(),
                points: drawingContextMenu.drawing.points.map((p) => ({
                  time: p.time + 60,
                  price: p.price * 1.002,
                })),
              };
              onAddDrawing(dup);
              setSelectedDrawingId(dup.id);
              setDrawingContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2A2E39] flex items-center gap-2 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5 text-[#089981]" />
            <span>Duplicate Drawing</span>
          </button>
          <button
            onClick={() => {
              onUpdateDrawing({
                ...drawingContextMenu.drawing,
                locked: !drawingContextMenu.drawing.locked,
              });
              setDrawingContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2A2E39] flex items-center gap-2 cursor-pointer"
          >
            {drawingContextMenu.drawing.locked ? (
              <>
                <Unlock className="w-3.5 h-3.5 text-[#F59E0B]" />
                <span>Unlock Drawing</span>
              </>
            ) : (
              <>
                <Lock className="w-3.5 h-3.5 text-[#F59E0B]" />
                <span>Lock Drawing</span>
              </>
            )}
          </button>
          <button
            onClick={() => {
              onUpdateDrawing({
                ...drawingContextMenu.drawing,
                hidden: !drawingContextMenu.drawing.hidden,
              });
              setDrawingContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2A2E39] flex items-center gap-2 cursor-pointer"
          >
            <EyeOff className="w-3.5 h-3.5 text-[#787B86]" />
            <span>Hide Drawing</span>
          </button>
          <button
            onClick={() => {
              onDeleteDrawing(drawingContextMenu.drawing.id);
              setSelectedDrawingId(null);
              setDrawingContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-[#2A2E39] flex items-center gap-2 text-[#F23645] cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete Drawing</span>
          </button>
        </div>
      )}
    </div>
  );
};
