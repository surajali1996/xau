import React, { useState } from 'react';
import {
  MousePointer,
  TrendingUp,
  Minus,
  MoveVertical,
  ArrowUpRight,
  Maximize2,
  Square,
  Circle,
  Paintbrush,
  ArrowRight,
  Type,
  GitCommit,
  GitBranch,
  Ruler,
  CalendarRange,
  Percent,
  Sliders,
  Trash2,
  Star,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Magnet,
  Undo2,
  Redo2,
  PanelLeftClose,
  PanelLeftOpen,
  Tag,
  Crosshair,
  Layers,
  Spline,
} from 'lucide-react';
import { DrawingTool } from '../types';

interface DrawingToolbarProps {
  activeTool: DrawingTool;
  onSelectTool: (tool: DrawingTool) => void;
  drawingsCount: number;
  onClearDrawings: () => void;
  onOpenSettings: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  favoriteTools: DrawingTool[];
  onToggleFavorite: (tool: DrawingTool) => void;
  magnetMode: boolean;
  onToggleMagnetMode: () => void;
  isAllLocked: boolean;
  onToggleLockAll: () => void;
  isAllHidden: boolean;
  onToggleHideAll: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
}

export const DrawingToolbar: React.FC<DrawingToolbarProps> = ({
  activeTool,
  onSelectTool,
  drawingsCount,
  onClearDrawings,
  onOpenSettings,
  isCollapsed,
  onToggleCollapse,
  favoriteTools,
  onToggleFavorite,
  magnetMode,
  onToggleMagnetMode,
  isAllLocked,
  onToggleLockAll,
  isAllHidden,
  onToggleHideAll,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
}) => {
  const [openFlyoutCategory, setOpenFlyoutCategory] = useState<string | null>(null);

  const categories = [
    {
      id: 'lines',
      label: 'Trend & Lines',
      icon: <TrendingUp className="w-4 h-4" />,
      tools: [
        { id: 'trendline' as DrawingTool, label: 'Trend Line', icon: <TrendingUp className="w-4 h-4" /> },
        { id: 'horizontal_line' as DrawingTool, label: 'Horizontal Line', icon: <Minus className="w-4 h-4" /> },
        { id: 'horizontal_ray' as DrawingTool, label: 'Horizontal Ray', icon: <ArrowRight className="w-4 h-4" /> },
        { id: 'vertical_line' as DrawingTool, label: 'Vertical Line', icon: <MoveVertical className="w-4 h-4" /> },
        { id: 'ray' as DrawingTool, label: 'Ray', icon: <ArrowUpRight className="w-4 h-4" /> },
        { id: 'extended_line' as DrawingTool, label: 'Extended Line', icon: <Maximize2 className="w-4 h-4" /> },
        { id: 'arrow' as DrawingTool, label: 'Arrow', icon: <ArrowRight className="w-4 h-4" /> },
        { id: 'cross_line' as DrawingTool, label: 'Cross Line', icon: <Crosshair className="w-4 h-4" /> },
      ],
    },
    {
      id: 'shapes',
      label: 'Channels & Shapes',
      icon: <Square className="w-4 h-4" />,
      tools: [
        { id: 'rectangle' as DrawingTool, label: 'Rectangle', icon: <Square className="w-4 h-4" /> },
        { id: 'circle' as DrawingTool, label: 'Circle', icon: <Circle className="w-4 h-4" /> },
        { id: 'ellipse' as DrawingTool, label: 'Ellipse', icon: <Circle className="w-4 h-4 scale-x-125" /> },
        { id: 'parallel_channel' as DrawingTool, label: 'Parallel Channel', icon: <Layers className="w-4 h-4" /> },
        { id: 'brush' as DrawingTool, label: 'Brush (Freehand)', icon: <Paintbrush className="w-4 h-4" /> },
        { id: 'polyline' as DrawingTool, label: 'Polyline / Path', icon: <Spline className="w-4 h-4" /> },
      ],
    },
    {
      id: 'fib',
      label: 'Fibonacci Tools',
      icon: <GitCommit className="w-4 h-4" />,
      tools: [
        { id: 'fibonacci' as DrawingTool, label: 'Fibonacci Retracement', icon: <GitCommit className="w-4 h-4" /> },
        { id: 'fibonacci_extension' as DrawingTool, label: 'Fibonacci Extension (3-Point)', icon: <GitBranch className="w-4 h-4" /> },
        { id: 'fibonacci_channel' as DrawingTool, label: 'Fibonacci Channel', icon: <Layers className="w-4 h-4" /> },
        { id: 'fibonacci_timezones' as DrawingTool, label: 'Fibonacci Time Zones', icon: <CalendarRange className="w-4 h-4" /> },
      ],
    },
    {
      id: 'annotation',
      label: 'Text & Labels',
      icon: <Type className="w-4 h-4" />,
      tools: [
        { id: 'text' as DrawingTool, label: 'Text Note', icon: <Type className="w-4 h-4" /> },
        { id: 'price_label' as DrawingTool, label: 'Price Label Badge', icon: <Tag className="w-4 h-4" /> },
        { id: 'arrow_marker' as DrawingTool, label: 'Arrow Marker (Buy/Sell)', icon: <ArrowUpRight className="w-4 h-4" /> },
      ],
    },
    {
      id: 'measure',
      label: 'Measurement Tools',
      icon: <Ruler className="w-4 h-4" />,
      tools: [
        { id: 'price_percentage_measure' as DrawingTool, label: 'Price Percentage (% & Bars)', icon: <Percent className="w-4 h-4 text-[#089981]" /> },
        { id: 'price_range' as DrawingTool, label: 'Price Range', icon: <Ruler className="w-4 h-4" /> },
        { id: 'date_and_price_range' as DrawingTool, label: 'Date and Price Range', icon: <CalendarRange className="w-4 h-4" /> },
        { id: 'date_range' as DrawingTool, label: 'Date Range (Bars)', icon: <CalendarRange className="w-4 h-4" /> },
      ],
    },
  ];

  // Collapsed state: Render minimalist expand button
  if (isCollapsed) {
    return (
      <div className="absolute left-1 top-12 z-30">
        <button
          onClick={onToggleCollapse}
          className="w-7 h-8 bg-[#1E222D]/95 border border-[#2B2F3A] rounded-r-md flex items-center justify-center text-[#787B86] hover:text-[#2962FF] hover:bg-[#2A2E39] shadow-lg transition-colors cursor-pointer"
          title="Expand Drawing Toolbar"
        >
          <PanelLeftOpen className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <aside
      className="w-11 md:w-12 bg-[#131722] border-r border-[#2B2F3A] flex flex-col items-center py-1.5 gap-1 shrink-0 select-none z-30 transition-all duration-200"
      aria-label="Drawing Tools"
    >
      {/* Collapse button */}
      <button
        onClick={onToggleCollapse}
        className="w-8 h-6 rounded flex items-center justify-center text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D] transition-colors mb-0.5 cursor-pointer"
        title="Collapse Drawing Toolbar"
      >
        <PanelLeftClose className="w-3.5 h-3.5" />
      </button>

      {/* DEDICATED CURSOR / SELECT BUTTON */}
      <button
        onClick={() => {
          onSelectTool('cursor');
          setOpenFlyoutCategory(null);
        }}
        title="Cursor / Select Mode"
        className={`w-8 h-8 rounded flex items-center justify-center transition-colors cursor-pointer relative ${
          activeTool === 'cursor'
            ? 'bg-[#2962FF] text-white shadow-xs'
            : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D]'
        }`}
      >
        <MousePointer className="w-4 h-4" />
      </button>

      <div className="w-6 h-px bg-[#2B2F3A] my-0.5" />

      {/* TOOL CATEGORIES */}
      {categories.map((cat) => {
        const hasActiveTool = cat.tools.some((t) => t.id === activeTool);
        const isOpen = openFlyoutCategory === cat.id;

        return (
          <div key={cat.id} className="relative">
            <button
              onClick={() => {
                setOpenFlyoutCategory(isOpen ? null : cat.id);
              }}
              title={cat.label}
              className={`w-8 h-8 rounded flex items-center justify-center transition-colors relative cursor-pointer ${
                hasActiveTool
                  ? 'bg-[#2962FF] text-white shadow-xs'
                  : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D]'
              }`}
            >
              {hasActiveTool
                ? cat.tools.find((t) => t.id === activeTool)?.icon
                : cat.icon}
              <div className="absolute bottom-0.5 right-0.5 w-1 h-1 bg-current opacity-70 rounded-full" />
            </button>

            {/* Flyout Submenu with Favourite Star Icons */}
            {isOpen && (
              <div className="absolute left-10 top-0 ml-1 bg-[#1E222D] border border-[#2B2F3A] rounded-lg shadow-2xl py-1 z-50 min-w-64 text-[#D1D4DC] backdrop-blur-md">
                <div className="px-3 py-1.5 text-[10px] uppercase font-semibold text-[#787B86] border-b border-[#2B2F3A] flex items-center justify-between">
                  <span>{cat.label}</span>
                  <span className="text-[9px] text-[#787B86]">★ Favorite</span>
                </div>
                {cat.tools.map((t) => {
                  const isFav = favoriteTools.includes(t.id);
                  const isCurrent = activeTool === t.id;

                  return (
                    <div
                      key={t.id}
                      className={`flex items-center justify-between px-3 py-2 text-xs hover:bg-[#2A2E39] transition-colors ${
                        isCurrent ? 'bg-[#2A2E39]/60 text-[#2962FF] font-semibold' : ''
                      }`}
                    >
                      <button
                        onClick={() => {
                          onSelectTool(t.id);
                          setOpenFlyoutCategory(null);
                        }}
                        className="flex-1 flex items-center gap-2 text-left cursor-pointer truncate mr-2"
                        title={t.label}
                      >
                        <span className="shrink-0">{t.icon}</span>
                        <span className="truncate">{t.label}</span>
                      </button>

                      {/* Favorite Star Icon */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(t.id);
                        }}
                        className={`p-1 rounded hover:bg-[#131722] transition-colors cursor-pointer ${
                          isFav ? 'text-[#F59E0B]' : 'text-[#787B86]/50 hover:text-[#F59E0B]'
                        }`}
                        title={isFav ? 'Remove from favorites' : 'Add to favorites'}
                      >
                        <Star className={`w-3.5 h-3.5 ${isFav ? 'fill-current' : ''}`} />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}

      <div className="w-6 h-px bg-[#2B2F3A] my-0.5" />

      {/* MAGNET MODE (Snap anchors to candle OHLC values) */}
      <button
        onClick={onToggleMagnetMode}
        title={magnetMode ? 'Magnet Mode: ON (Snaps points to OHLC prices)' : 'Magnet Mode: OFF (Free placement)'}
        className={`w-8 h-8 rounded flex items-center justify-center transition-colors cursor-pointer ${
          magnetMode
            ? 'bg-[#2962FF] text-white shadow-xs'
            : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D]'
        }`}
      >
        <Magnet className="w-4 h-4" />
      </button>

      {/* LOCK ALL DRAWINGS */}
      <button
        onClick={onToggleLockAll}
        title={isAllLocked ? 'Unlock All Drawings' : 'Lock All Drawings'}
        className={`w-8 h-8 rounded flex items-center justify-center transition-colors cursor-pointer ${
          isAllLocked
            ? 'bg-[#F59E0B] text-black shadow-xs'
            : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D]'
        }`}
      >
        {isAllLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
      </button>

      {/* HIDE / SHOW ALL DRAWINGS */}
      <button
        onClick={onToggleHideAll}
        title={isAllHidden ? 'Show All Drawings' : 'Hide All Drawings'}
        className={`w-8 h-8 rounded flex items-center justify-center transition-colors cursor-pointer ${
          isAllHidden
            ? 'bg-[#F23645]/20 text-[#F23645]'
            : 'text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D]'
        }`}
      >
        {isAllHidden ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
      </button>

      {/* UNDO / REDO */}
      <div className="flex flex-col gap-0.5">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          title="Undo Drawing"
          className="w-8 h-6 rounded flex items-center justify-center text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D] disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
        >
          <Undo2 className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={onRedo}
          disabled={!canRedo}
          title="Redo Drawing"
          className="w-8 h-6 rounded flex items-center justify-center text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D] disabled:opacity-30 disabled:pointer-events-none transition-colors cursor-pointer"
        >
          <Redo2 className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="w-6 h-px bg-[#2B2F3A] my-0.5" />

      {/* DRAWING SETTINGS TRIGGER */}
      <button
        onClick={onOpenSettings}
        title="Drawing Defaults & Settings"
        className="w-8 h-8 rounded flex items-center justify-center text-[#787B86] hover:text-[#D1D4DC] hover:bg-[#1E222D] transition-colors cursor-pointer"
      >
        <Sliders className="w-4 h-4" />
      </button>

      {/* REMOVE ALL DRAWINGS BUTTON */}
      <button
        onClick={() => {
          if (drawingsCount > 0 && window.confirm(`Remove all ${drawingsCount} drawings on this chart?`)) {
            onClearDrawings();
          }
        }}
        disabled={drawingsCount === 0}
        title={drawingsCount > 0 ? `Remove All ${drawingsCount} Drawings` : 'No active drawings'}
        className={`w-8 h-8 rounded flex items-center justify-center transition-colors ${
          drawingsCount > 0
            ? 'text-[#787B86] hover:text-[#F23645] hover:bg-[#1E222D] cursor-pointer'
            : 'text-[#787B86]/30 cursor-not-allowed'
        }`}
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </aside>
  );
};
